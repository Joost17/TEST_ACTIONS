 # -*- coding: utf-8 -*-
"""
@author: Joost Driebergen
"""

import logging
from logging import handlers

class Utils:
    @staticmethod
    def set_up_single_logging(logfile, level):
        logger = logging.getLogger('logger')
        logger.setLevel(level)
    
        current_log_handler = logging.FileHandler(filename=logfile, mode='w')
        current_log_handler.setFormatter(Utils.get_formatter())
        logger.addHandler(current_log_handler)
        return logger

    @staticmethod
    def set_up_logging(logfile, loghistoryfile, level):
        logger = Utils.set_up_single_logging(logfile, level)
        history_log_handler = handlers.RotatingFileHandler(loghistoryfile, maxBytes=10000000, backupCount=5)
        history_log_handler.setFormatter(Utils.get_formatter())
        logger.addHandler(history_log_handler)
        return logger

    @staticmethod
    def get_handler(logfile):
        current_log_handler = logging.FileHandler(filename=logfile, mode='w')
        current_log_handler.setFormatter(Utils.get_formatter())
        return current_log_handler

    @staticmethod
    def get_formatter():
        fmt = r'%(asctime)s %(levelname)s: %(message)s'
        dfmt = r'%Y-%m-%d %H:%M:%S'
        return logging.Formatter(fmt, datefmt=dfmt)
    
        
        
#%%


