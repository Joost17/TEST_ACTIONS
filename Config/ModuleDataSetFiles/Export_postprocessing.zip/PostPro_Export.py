# -*- coding: utf-8 -*-
"""
Created on Mon Sep 21 13:24:40 2020

@author: driebergen

"""
import pandas as pd
from utils_EFCIS import Utils as UtilsEFCIS
import logging
import sys
from pathlib import Path
import numpy as np
import time
import os

pd.options.mode.chained_assignment = None  # ignore warnings; default='warn'
          

def postprocessing(export_folder,sample_id_kolom,pattern,logger):
    files = [x for x in export_folder.glob('*'+pattern+'*.csv') if x.is_file()]
    threshold = 10 
    files_threshold = [file for file in files if (time.time() - os.path.getmtime(file)) < threshold]
    logger.info('Found {} files that are newer than {} seconds'.format(len(files_threshold),threshold))
    dtypes_standaard = {'Kwaliteitsoordeel': object,'Kwaliteitsoordeel.code':object}
    for file in files_threshold:
        logger.info('Reading file {}'.format(file))
        col_names = pd.read_csv(file,sep=';',engine='python', nrows=0).columns
        dtypes = {col:dtypes_standaard[col] for col in col_names if col in dtypes_standaard.keys()}
        df= pd.read_csv(file,sep=';',engine = 'python',dtype=dtypes)
        if not 'Meetwaarde.lokaalID' in df.columns:
            logger.info('Meetwaarde.lokaalID not in csv file, adding it based on {}'.format(sample_id_kolom))
            df.loc[df[sample_id_kolom].isnull(),sample_id_kolom] = ''
            meetwaarde_ids = [row[sample_id_kolom] + '_' + str(idx+1) for idx,row in df.iterrows()]
            df.insert(0,'Meetwaarde.lokaalID',meetwaarde_ids)
            logger.info('Writing file {}'.format(file))
            df.to_csv(file,sep=';',index=False)
        else:
            logger.info('Meetwaarde.lokaalID already in csv file, skipping')

def main(argv):
    sample_id_col = argv[0]
    pattern       = argv[1]
    export_dir    = Path(argv[2])
    log_dir       = Path(argv[3])
    loghistorydir = log_dir / 'loghistory'

    log_dir.mkdir(exist_ok=True)
    loghistorydir.mkdir(exist_ok=True)
    
    logger = UtilsEFCIS.set_up_logging(log_dir / 'log_PostProExport.txt',
                                      loghistorydir / 'log_PostProExport.txt', logging.DEBUG)

    logger.info('Starting postprocessing exported files')
    logger.info('Export directory : {}'.format(export_dir))
    logger.info('Sample id col : {}'.format(sample_id_col))
    logger.info('Pattern: {}'.format(pattern))
    #try:
    postprocessing(export_dir,sample_id_col,pattern, logger)
    #except:
    #    logger.error('Something whent wrong in postprocessing script')
        
if __name__ == "__main__":
    if len(sys.argv)>1:
        main(sys.argv[1:])
    else:  
        args = ['Monster.lokaalID',
                'export_alles',
                r'D:/FEWSProjects/FEWS-EFCIS_HKV/branches/2020-02-test/FEWS/fromfss/export/IMmetingen/CSV',
                r'D:\FEWSProjects\FEWS-EFCIS_HKV\branches\2020-02-test\FEWS\fromfss\ExportPostPro_Logging'
                 ]
        main(args)
      


#%%
#for idx,col in enumerate(df_import_chemie.columns):
#    if not df_import_chemie.dtypes[col] == df_import_chemie.convert_dtypes().dtypes[col]:
#        print(idx)


