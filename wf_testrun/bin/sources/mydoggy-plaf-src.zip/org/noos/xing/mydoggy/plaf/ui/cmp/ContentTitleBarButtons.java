package org.noos.xing.mydoggy.plaf.ui.cmp;

import info.clearthought.layout.TableLayout;
import org.noos.xing.mydoggy.Content;
import org.noos.xing.mydoggy.ToolWindowType;
import org.noos.xing.mydoggy.plaf.MyDoggyToolWindowManager;
import org.noos.xing.mydoggy.plaf.cleaner.Cleaner;
import org.noos.xing.mydoggy.plaf.ui.MyDoggyKeySpace;
import org.noos.xing.mydoggy.plaf.ui.ResourceManager;
import org.noos.xing.mydoggy.plaf.ui.TitleBarButtons;
import org.noos.xing.mydoggy.plaf.ui.content.ContentContainer;
import org.noos.xing.mydoggy.plaf.ui.content.ContentDescriptor;
import org.noos.xing.mydoggy.plaf.ui.util.SwingUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 * @author EDR Added ContentContainer to change look and feel of Undocked content
 */
public class ContentTitleBarButtons extends JPanel implements TitleBarButtons, Cleaner {
    protected Content content;
    private MyDoggyToolWindowManager manager;

    protected transient ResourceManager resourceManager;
    protected ContentContainer dockedContainer;

    private TableLayout containerLayout = null;
    private Component focusable = null;
    private PropertyChangeListener closeableListener = null;
    private MaximizeAction maximizeAction = null;
    private boolean maximized = false;


    public ContentTitleBarButtons(ContentDescriptor descriptor, ContentContainer contentContainer) {

        this.manager = descriptor.getManager();
        this.content = (Content) descriptor.getDockable();
        dockedContainer = contentContainer;
        this.resourceManager = this.manager.getResourceManager();
        descriptor.getCleaner().addCleaner(this);
        initComponents();
        initListeners();
    }

    @Override
    public Component getFocusable() {
        return focusable;
    }

    @Override
    public Component getComponent() {
        return this;
    }

    @Override
    public void setType(ToolWindowType type) {
        
    }

    protected void initComponents() {
        removeAll();
        setLayout(containerLayout = new ExtendedTableLayout(new double[][]{{0, 0}, {1, 14, 1}}, false));
        setOpaque(false);

        focusable = addTitleBarAction(new DockAction());
        maximizeAction = new MaximizeAction();
        addTitleBarAction(maximizeAction);
        MinimizeAction minimizeAction = new MinimizeAction();
        addTitleBarAction(minimizeAction);
        if (content.getContentUI().isCloseable())
            addTitleBarAction(new CloseAction());
    }

    protected void initListeners() {

        closeableListener = evt -> initComponents();
        content.getContentUI().addPropertyChangeListener("closable", closeableListener);
    }

    private Component addTitleBarAction(TitleBarAction titleBarAction) {
        return addTitleBarAction(-1, titleBarAction);
    }

    @SuppressWarnings("Duplicates")
    private Component addTitleBarAction(int index, TitleBarAction titleBarAction) {
        int row;
        if (index == -1) {
            double[] oldCols = containerLayout.getColumn();

            double[] newCols;
            if (oldCols.length == 2) {
                newCols = new double[]{0, 13, 0};
                row = 1;
            } else {
                newCols = new double[oldCols.length + 2];

                System.arraycopy(oldCols, 0, newCols, 0, oldCols.length);
                newCols[oldCols.length - 1] = 1;
                newCols[oldCols.length] = 13;
                newCols[oldCols.length + 1] = 0;
                row = oldCols.length;
            }
            containerLayout.setColumn(newCols);
        } else {
            throw new IllegalStateException("Not implemented yet!!!");
        }

        JButton button = (JButton) resourceManager.createComponent(
                MyDoggyKeySpace.TOOL_WINDOW_TITLE_BUTTON,
                manager.getContext()
        );
        button.setAction(titleBarAction);
        button.setName((String) titleBarAction.getValue("action.name"));
        titleBarAction.putValue("component", button);

        add(button, row + ",1,FULL,FULL");

        return button;
    }

    @SuppressWarnings("Duplicates")
    protected void setVisible(Component component, boolean visible) {
        for (Component cmp : getComponents()) {
            if (cmp == component) {
                if (visible) {
                    int col = containerLayout.getConstraints(component).col1;
                    containerLayout.setColumn(col, 13);
                    if (col != containerLayout.getColumn().length - 1)
                        containerLayout.setColumn(col + 1, 1);
                } else {
                    int col = containerLayout.getConstraints(component).col1;
                    containerLayout.setColumn(col, 0);
                    if (col != containerLayout.getColumn().length - 1)
                        containerLayout.setColumn(col + 1, 0);
                }
            }
        }

    }


    @Override
    public void cleanup() {
        content.getContentUI().removePropertyChangeListener("closable", closeableListener);
        manager = null;
        content = null;
        resourceManager = null;
    }


    protected abstract class TitleBarAction extends AbstractAction implements PropertyChangeListener {

        TitleBarAction(String name, String icon, String tooltip) {
            putValue("action.name", name);
            putValue(Action.SMALL_ICON, resourceManager.getIcon(icon));
            putValue(Action.SHORT_DESCRIPTION, resourceManager.getString(tooltip));
        }

        public void setVisible(boolean visible) {
            ContentTitleBarButtons.this.setVisible((Component) getValue("component"), visible);
            SwingUtil.repaint(ContentTitleBarButtons.this);
        }

    }

    protected final class MaximizeAction extends TitleBarAction {

        private MaximizeAction() {
            super("content.maxButton." + content.getId(), MyDoggyKeySpace.MAXIMIZE, "@@tool.maximize");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (maximized){
                restoreAction();
            } else {
                maximizeAction();
            }
        }

        @Override
        public void propertyChange(PropertyChangeEvent evt) {
        }
    }

    protected final class MinimizeAction extends TitleBarAction {

        private MinimizeAction() {
            super("content.minButton." + content.getId(), MyDoggyKeySpace.TAB_MINIMIZE, "@@tool.tab.minimize");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            minimizeAction();
        }

        @Override
        public void propertyChange(PropertyChangeEvent evt) {
        }
    }

    private void restoreAction(){
        maximizeAction.putValue(Action.SMALL_ICON, resourceManager.getIcon(MyDoggyKeySpace.MAXIMIZE));
        maximizeAction.putValue(Action.SHORT_DESCRIPTION, resourceManager.getString("@@tool.maximize"));
        Container container = dockedContainer.getContainer();
        SwingUtil.restoreFullScreenWindow(container);
        SwingUtil.findAndRequestFocus(container);
        maximized = false;
    }

    private void maximizeAction() {
        maximizeAction.putValue(Action.SMALL_ICON, resourceManager.getIcon(MyDoggyKeySpace.MINIMIZE));
        maximizeAction.putValue(Action.SHORT_DESCRIPTION, resourceManager.getString("@@tool.maximize.restore"));
        Container container = dockedContainer.getContainer();
        SwingUtil.setFullScreen(container, false);
        SwingUtil.findAndRequestFocus(container);
        maximized = true;
    }

    private void minimizeAction() {
        Container container = dockedContainer.getContainer();
        ((JFrame)container).setState(Frame.ICONIFIED);
    }

    protected final class DockAction extends TitleBarAction {

        private DockAction() {
            super("content.dockButton." + content.getId(), MyDoggyKeySpace.FIX, "@@tool.tooltip.dock");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (content.isDetached() && content.isMaximized()){
                SwingUtil.restoreFullScreenWindow(dockedContainer.getContainer());
            }
            content.setDetached(false);
        }

        @Override
        public void propertyChange(PropertyChangeEvent evt) {
        }
    }

    protected class CloseAction extends TitleBarAction {

        public CloseAction() {
            super("content.closeButton." + content.getId(), MyDoggyKeySpace.TAB_CLOSE, "@@tab.content.close");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            //EDR FEWS-5477: NullPointerException: ContentTitleBarButtons$CloseAction.actionPerformed
            if (manager == null) return;
            manager.getContentManager().removeContent(content);
        }

        @Override
        public void propertyChange(PropertyChangeEvent evt) {
        }
    }

    public boolean isMaximized() {
        return maximized;
    }
}