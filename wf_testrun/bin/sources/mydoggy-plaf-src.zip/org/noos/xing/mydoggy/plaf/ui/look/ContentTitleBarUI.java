package org.noos.xing.mydoggy.plaf.ui.look;

import org.noos.xing.mydoggy.Content;
import org.noos.xing.mydoggy.plaf.cleaner.Cleaner;
import org.noos.xing.mydoggy.plaf.ui.DockableDescriptor;
import org.noos.xing.mydoggy.plaf.ui.MyDoggyKeySpace;
import org.noos.xing.mydoggy.plaf.ui.ResourceManager;
import org.noos.xing.mydoggy.plaf.ui.animation.AbstractAnimation;
import org.noos.xing.mydoggy.plaf.ui.content.ContentContainer;
import org.noos.xing.mydoggy.plaf.ui.content.ContentDescriptor;
import org.noos.xing.mydoggy.plaf.ui.util.GraphicsUtil;
import org.noos.xing.mydoggy.plaf.ui.util.MutableColor;
import org.noos.xing.mydoggy.plaf.ui.util.SwingUtil;

import javax.swing.*;
import javax.swing.plaf.PanelUI;
import java.awt.*;
import java.awt.geom.Arc2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 * @author EDR Added ContentContainer to change look and feel of Undocked content
 *
 */
public class ContentTitleBarUI extends PanelUI implements Cleaner {
    protected Content content;
    protected ContentDescriptor descriptor;
    protected ResourceManager resourceManager;

    protected MutableColor animBackStart;
    protected MutableColor animBackEnd;
    protected MutableColor animTextColor;

    protected JComponent panel;

    protected GradientAnimation animation;


    public ContentTitleBarUI(ContentDescriptor descriptor, ContentContainer dockedContainer) {
        this.descriptor = descriptor;
        this.content = (Content) descriptor.getDockable();
        this.resourceManager = descriptor.getResourceManager();

        dockedContainer.addPropertyChangeListener("active", new GradientActivationListener(descriptor));

        animBackStart = new MutableColor(resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_START));
        animBackEnd = new MutableColor(0, 0, 0);
        animTextColor = new MutableColor(0, 0, 0);
        animation = new GradientAnimation();

        descriptor.getCleaner().addCleaner(this);
    }


    public void installUI(JComponent c) {
        super.installUI(c);
        installDefaults(c);
        this.panel = c;

    }

    public void uninstallUI(JComponent c) {
        super.uninstallUI(c);
        uninstallDefaults(c);

        cleanup();
    }

    public void cleanup() {
        // Stop animations and time
        animation.stop();

        // Clean reference
        content = null;
        descriptor = null;
        resourceManager = null;
    }

    public void update(Graphics g, JComponent c) {

        assert(EventQueue.isDispatchThread());
        Rectangle r = c.getBounds();
        r.x = r.y = 0;
        if (resourceManager == null){
            //FEWS-3684: Cleanup method has been called either in different thread or something went wrong
            // with property change events.
            return;
        }

        updateToolWindowTitleBar(g, c,
                                 animBackStart, animBackEnd,
                                 resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_BACKGROUND_FLASHING_1),
                                 animTextColor);
        if (animation.isAnimating()) {
            updateToolWindowTitleBar(g, c,
                                     animBackStart, animBackEnd,
                                     resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_BACKGROUND_ANIMATING),
                                     animTextColor);
        } else if (c.isEnabled()) {
            updateToolWindowTitleBar(g, c,
                                     resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_START),
                                     resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_END),
                                     resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_BACKGROUND_ACTIVE),
                                     resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_FOREGROUND_ACTIVE));
        } else {
            updateToolWindowTitleBar(g, c,
                                     resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_START),
                                     resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_END),
                                     resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_BACKGROUND_INACTIVE),
                                     resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_FOREGROUND_INACTIVE));
        }

        paint(g, c);
    }


    protected void installDefaults(JComponent c) {
        LookAndFeel.installColorsAndFont(c, "Panel.background", "Panel.foreground", "Panel.font");
        LookAndFeel.installBorder(c, "Panel.border");
    }

    protected void uninstallDefaults(JComponent c) {
        LookAndFeel.uninstallBorder(c);
    }

    protected void updateToolWindowTitleBar(Graphics g, JComponent c,
                                            Color backgroundStart, Color backgroundEnd,
                                            Color idBackgroundColor, Color idColor) {

        Rectangle r = c.getBounds();
        r.x = r.y = 0;

        GraphicsUtil.fillRect(g, r,
                              backgroundStart, backgroundEnd,
                              null,
                              GraphicsUtil.UP_TO_BOTTOM_GRADIENT);

        if (descriptor.isIdVisibleOnTitleBar()) {
            String id = resourceManager.getUserString(descriptor.getDockable().getId());
            r.width = g.getFontMetrics().stringWidth(id) + 8;

            int halfHeigh = (r.height / 2);
            GraphicsUtil.fillRect(g, r,
                                  Color.WHITE,
                                  idBackgroundColor,
                                  new Polygon(new int[]{r.x, r.x + r.width - halfHeigh, r.x + r.width - halfHeigh, r.x},
                                              new int[]{r.y, r.y, r.y + r.height, r.y + r.height},
                                              4),
                                  GraphicsUtil.UP_TO_BOTTOM_GRADIENT);

            GraphicsUtil.fillRect(g, r,
                                  Color.WHITE,
                                  idBackgroundColor,
                                  new Arc2D.Double(r.x + r.width - r.height,
                                                   r.y, r.height, r.height, -90.0d, 180.0d, Arc2D.CHORD),
                                  GraphicsUtil.UP_TO_BOTTOM_GRADIENT);

            g.setColor(idColor);
            g.drawString(id,
                         r.x + 2,
                         r.y + ((r.height - g.getFontMetrics().getHeight()) / 2) + g.getFontMetrics().getAscent());
        }
    }


    protected class GradientActivationListener implements PropertyChangeListener {
        public static final float ANIMATION_DURATION = 80f;
        public static final int ANIMATION_SLEEP = 10;

        protected DockableDescriptor descriptor;

        public GradientActivationListener(DockableDescriptor descriptor) {
            this.descriptor = descriptor;
        }

        public synchronized void propertyChange(PropertyChangeEvent evt) {
            if (evt.getSource() != descriptor || !descriptor.getDockable().getComponent().isVisible())
                return;

            assert evt.getPropertyName() != null;
            assert descriptor.getDockable().getComponent().isVisible();

            if ("active".equals(evt.getPropertyName())) {
                if (evt.getNewValue() == Boolean.FALSE) {
                    if (animBackStart.equals(resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_START)))
                        animation.hide();
                } else {
                    if (animBackStart.equals(resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_START)))
                        animation.show();
                }
            }
        }
    }

    protected class GradientAnimation extends AbstractAnimation {

        public GradientAnimation() {
            super(300f);
        }

        protected GradientAnimation(float animationDuration) {
            super(animationDuration);
        }

        protected float onAnimating(float animationPercent) {
            switch (getAnimationDirection()) {
                case INCOMING:
                    GraphicsUtil.getInterpolatedColor(animBackStart,
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_START),
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_START),
                                                      animationPercent);
                    GraphicsUtil.getInterpolatedColor(animBackEnd,
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_END),
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_END),
                                                      animationPercent);
                    GraphicsUtil.getInterpolatedColor(animTextColor,
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_FOREGROUND_ACTIVE),
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_FOREGROUND_INACTIVE),
                                                      animationPercent);
                    break;

                case OUTGOING:
                    GraphicsUtil.getInterpolatedColor(animBackStart,
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_START),
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_START),
                                                      animationPercent);
                    GraphicsUtil.getInterpolatedColor(animBackEnd,
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_END),
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_END),
                                                      animationPercent);
                    GraphicsUtil.getInterpolatedColor(animTextColor,
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_FOREGROUND_INACTIVE),
                                                      resourceManager.getColor(MyDoggyKeySpace.TWTB_ID_FOREGROUND_ACTIVE),
                                                      animationPercent);
                    break;
            }
            SwingUtil.repaint(panel);
            return animationPercent;
        }

        protected void onFinishAnimation() {
            switch (getAnimationDirection()) {
                case INCOMING:
                    animBackStart.setRGB(resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_START));
                    break;
                case OUTGOING:
                    animBackStart.setRGB(resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_START));
                    break;
            }
            SwingUtil.repaint(panel);
        }

        protected void onHide(Object... params) {
            animBackStart.setRGB(resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_START));
            animBackEnd.setRGB(resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_ACTIVE_END));
        }

        protected void onShow(Object... params) {
            animBackStart.setRGB(resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_START));
            animBackEnd.setRGB(resourceManager.getColor(MyDoggyKeySpace.TWTB_BACKGROUND_INACTIVE_END));
        }

        protected void onStartAnimation(Direction direction) {
        }

        protected Direction chooseFinishDirection(Type type) {
            return (type == Type.SHOW) ? Direction.OUTGOING : Direction.INCOMING;
        }

    }

}