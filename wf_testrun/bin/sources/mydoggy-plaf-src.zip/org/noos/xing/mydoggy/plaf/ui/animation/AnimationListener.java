package org.noos.xing.mydoggy.plaf.ui.animation;

import java.util.EventListener;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface AnimationListener extends EventListener {

    void onFinished();

}
