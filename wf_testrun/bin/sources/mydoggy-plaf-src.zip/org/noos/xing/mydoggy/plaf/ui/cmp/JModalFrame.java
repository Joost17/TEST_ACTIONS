package org.noos.xing.mydoggy.plaf.ui.cmp;

import org.noos.xing.mydoggy.Dockable;
import org.noos.xing.mydoggy.plaf.ui.ResourceManager;
import org.noos.xing.mydoggy.plaf.ui.transparency.TransparencyManager;
import org.noos.xing.mydoggy.plaf.ui.util.SwingUtil;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;

public class JModalFrame extends JFrame implements ModalWindow {
    protected ResourceManager resourceManager;
    protected Window modalToWindow;
    protected boolean notifiedModalToWindow;
    protected Component returnFocus;

    /**
     * EDR Added this method to convert icons assigned to Dockable to Images
     * @param icon
     * @return
     */
    static Image iconToImage(Icon icon) {
        if (icon instanceof ImageIcon) {
            return ((ImageIcon) icon).getImage();
        } else {
            int w = icon.getIconWidth();
            int h = icon.getIconHeight();
            GraphicsEnvironment ge =
                    GraphicsEnvironment.getLocalGraphicsEnvironment();
            GraphicsDevice gd = ge.getDefaultScreenDevice();
            GraphicsConfiguration gc = gd.getDefaultConfiguration();
            BufferedImage image = gc.createCompatibleImage(w, h);
            Graphics2D g = image.createGraphics();
            icon.paintIcon(null, g, 0, 0);
            g.dispose();
            return image;
        }
    }

    public JModalFrame(Dockable dockable, ResourceManager resourceManager, Window owner, Component returnFocus, boolean modal) {
        setAlwaysOnTop(owner != null);
        if (!SwingUtil.isX11() || !SwingUtil.isWsl()) setUndecorated(true);
        /**
         * EDR. If title is NULL insert ID as title
         */
        //setTitle(dockable.getTitle());
        if (dockable.getTitle() != null){
            setTitle(dockable.getTitle());
        }
        else {
            setTitle(dockable.getId());
        }
        /**
         * EDR. If icon not NULL then add it to frame
         */
        if (dockable.getIcon() != null){
            var image = iconToImage(dockable.getIcon());
            if (SwingUtil.isX11() && SwingUtil.isWsl()) image = image.getScaledInstance(32, 32, Image.SCALE_SMOOTH);
            setIconImage(image);
        }

        this.resourceManager = resourceManager;
        setFocusableWindowState(true);
        this.returnFocus = returnFocus;
        synchronized (JModalFrame.this) {
            if (modal)
                modalToWindow = owner;

            notifiedModalToWindow = true;
        }

        enableEvents(WindowEvent.WINDOW_EVENT_MASK | ComponentEvent.MOUSE_MOTION_EVENT_MASK);
    }

    public void setVisible(boolean visible) {
        if (!visible) {
            TransparencyManager<Window> transparencyManager = resourceManager.getTransparencyManager();
            transparencyManager.setAlphaModeRatio(this, 0.0f);

            restoreOwner();
        } else {
            if (!isVisible()) {
                synchronized (JModalFrame.this) {
                    if ((modalToWindow != null) && notifiedModalToWindow) {
                        modalToWindow.setEnabled(false);
                        notifiedModalToWindow = false;
                    }
                }
            }
        }

        super.setVisible(visible);
    }

    protected void processWindowEvent(WindowEvent windowEvent) {
        switch (windowEvent.getID()) {
            case WindowEvent.WINDOW_CLOSING:
                tryToDispose(windowEvent);
                break;
            case WindowEvent.WINDOW_CLOSED:
                close(windowEvent);
                break;
            default:
                super.processWindowEvent(windowEvent);
                break;
        }
    }


    public Window getWindow() {
        return this;
    }

    public void setModal(boolean modal) {
        synchronized (JModalFrame.this) {
            modalToWindow = modal ? getOwner() : null;
        }
    }

    public boolean isModal() {
        synchronized (JModalFrame.this) {
            return modalToWindow != null;
        }
    }


    protected void restoreOwner() {
        synchronized (JModalFrame.this) {
            if ((modalToWindow != null) && !notifiedModalToWindow) {
                modalToWindow.setEnabled(true);
                modalToWindow.toFront();
                notifiedModalToWindow = true;
            }

            if (returnFocus != null) {
                Window owner = SwingUtilities.windowForComponent(returnFocus);
                boolean stillBusy;

                stillBusy = !owner.isEnabled();

                if (!stillBusy) {
                    returnFocus.requestFocusInWindow();
                }
            }
        }
    }

    protected void tryToDispose(WindowEvent windowEvent) {
        dispose();
        super.processWindowEvent(windowEvent);
    }

    protected void close(WindowEvent windowEvent) {
        restoreOwner();
        super.processWindowEvent(windowEvent);
    }

    @Override
    public void dispose() {
        if (EventQueue.isDispatchThread()) {
            super.dispose();
        } else {
            EventQueue.invokeLater(this::dispose);
        }
    }

}
