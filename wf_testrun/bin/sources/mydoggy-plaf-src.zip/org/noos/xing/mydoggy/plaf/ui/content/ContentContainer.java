package org.noos.xing.mydoggy.plaf.ui.content;

import info.clearthought.layout.TableLayout;
import info.clearthought.layout.TableLayoutConstants;
import org.noos.xing.mydoggy.Content;
import org.noos.xing.mydoggy.ContentUI;
import org.noos.xing.mydoggy.ToolWindowType;
import org.noos.xing.mydoggy.plaf.cleaner.Cleaner;
import org.noos.xing.mydoggy.plaf.common.context.DefaultMutableContext;
import org.noos.xing.mydoggy.plaf.support.CleanablePropertyChangeSupport;
import org.noos.xing.mydoggy.plaf.ui.MyDoggyKeySpace;
import org.noos.xing.mydoggy.plaf.ui.ResourceManager;
import org.noos.xing.mydoggy.plaf.ui.cmp.ContentTitleBarButtons;
import org.noos.xing.mydoggy.plaf.ui.cmp.ExtendedTableLayout;
import org.noos.xing.mydoggy.plaf.ui.cmp.JModalFrame;
import org.noos.xing.mydoggy.plaf.ui.cmp.event.FloatingMoveMouseInputHandler;
import org.noos.xing.mydoggy.plaf.ui.cmp.event.FloatingResizeMouseInputHandler;
import org.noos.xing.mydoggy.plaf.ui.util.SwingUtil;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.plaf.PanelUI;
import javax.swing.plaf.basic.BasicLabelUI;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.ContainerOrderFocusTraversalPolicy;
import java.awt.Graphics;
import java.awt.KeyboardFocusManager;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 * EDR: Added this class to be able to change the look and feel of the undocked
 * content displays.
 * 
 */
public class ContentContainer implements Cleaner {

    protected JModalFrame window = null;
    private Rectangle lastBounds = null;

    private FloatingResizeMouseInputHandler resizeMouseInputHandler = null;
    private FloatingMoveMouseInputHandler moveMouseInputHandler = null;

    protected ContentDescriptor descriptor;
    protected Content content;
    protected transient ResourceManager resourceManager;

    protected JPanel container = null;
    private JPanel titleBar = null;
    private JLabel titleLabel = null;
    private ContentTitleBarButtons titleBarButtons = null;
    private JPanel componentContainer = null;

    private CleanablePropertyChangeSupport propertyChangeSupport = null;
    private PropertyChangeListener focusListener = null;

    private boolean valueAdjusting = false;
    private ContentDialogComponentAdapter componentAdapter = null;
    private final UIDefaults defaults;

    ContentContainer(ContentDescriptor descriptor) {

        this.descriptor = descriptor;
        this.content = (Content) this.descriptor.getDockable();
        this.resourceManager = descriptor.getResourceManager();

        this.descriptor.getCleaner().addCleaner(this);

        this.defaults = UIManager.getLookAndFeelDefaults();

        initComponents();
        initListeners();
    }

    public Container getContainer() {
        return window;
    }

    public void setVisible(boolean visible) {

        initComponents();
        initWindow();

        container.setFocusCycleRoot(!visible);

        if (visible) {
            // Setup toolwindow title bar components
            titleBarButtons.setType(ToolWindowType.FLOATING);

            // Add content to window
            window.getContentPane().removeAll();
            window.getContentPane().add(container, "1,1,FULL,FULL");
            container.setVisible(true);

            // Position window
            if (lastBounds == null) {

                ContentUI contentUI = content.getContentUI();
                Rectangle inBounds = descriptor.getManager().getBoundsToScreen(content.getComponent().getBounds(),
                        content.getComponent().getParent());

                // Setup bounds
                lastBounds = SwingUtil.validateBounds(contentUI.getDetachedBounds());
                if (lastBounds != null) {
                    window.setBounds(lastBounds);
                } else {
                    if (inBounds != null) {
                        window.setBounds(inBounds);
                    } else {
                        Window parentFrame = resourceManager.getBoolean("dialog.owner.enabled", true) ? descriptor.getWindowAnchestor() : null;
                        if (parentFrame != null) {
                            Point location = parentFrame.getLocation();
                            location.translate(5, 5);
                            window.setLocation(location);
                        } else {
                            SwingUtil.centrePositionOnScreen(window);
                        }
                    }
                }

            } else {
                window.setBounds(lastBounds);
                lastBounds = null;
            }

            // Show the window
            window.setVisible(true);
            window.getContentPane().setVisible(true);
            SwingUtil.repaint(window.getWindow());
        } else {
            if (titleBarButtons.getFocusable().isFocusable())
                titleBarButtons.getFocusable().setFocusable(false);

            lastBounds = window.getBounds();

            window.getContentPane().setVisible(true);
            window.setVisible(false);
        }
    }

    private void initWindow() {
        if (window != null)
            return;

            window = new JModalFrame(content,
                    resourceManager,
                    resourceManager.getBoolean("dialog.owner.enabled", true) ? descriptor.getWindowAnchestor() : null,
                    null,
                    false){
                @Override
                /**
                 * EDR. This method is called when closing a window from the task bar.
                 * This needs to be intercepted so the content can be handled correctly
                 */
                protected void tryToDispose(WindowEvent windowEvent) {
                    if (content.getContentUI().isCloseable()){
                        content.getDockableManager().removeContent(content);
                    } else {
                        content.setDetached(false);
                    }
                }

                @Override
                public void dispose() {
                    disposeComponents();
                    super.dispose(); // fix added by OA
                }
            };

        window.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
        if (!content.getContentUI().isAddToTaskBarWhenDetached()) {
            window.setType(JFrame.Type.UTILITY);
        }

        window.setName("toolWindow.floating.window." + content.getId());

        JPanel contentPane = new JPanel(new ExtendedTableLayout(new double[][]{{1, TableLayoutConstants.FILL, 1}, {1, TableLayoutConstants.FILL, 1}}));
        contentPane.setBorder(BorderFactory.createLineBorder(defaults.getColor("panelBorder") != null ? defaults.getColor("panelBorder") : Color.GRAY));
        window.setContentPane(contentPane);
        window.setPreferredSize(content.getComponent().getSize());

        resizeMouseInputHandler = new FloatingResizeMouseInputHandler(window.getWindow());
        moveMouseInputHandler = new FloatingMoveMouseInputHandler(window.getWindow());

        initWindowListeners();
    }

    private void initWindowListeners() {

        // Remove listeners
        window.getWindow().removeMouseMotionListener(resizeMouseInputHandler);
        window.getWindow().removeMouseListener(resizeMouseInputHandler);

        titleBar.removeMouseMotionListener(moveMouseInputHandler);
        titleBar.removeMouseListener(moveMouseInputHandler);

        // Add listeners
        if (!SwingUtil.isX11() || !SwingUtil.isWsl()){
            window.getWindow().addMouseMotionListener(resizeMouseInputHandler);
            window.getWindow().addMouseListener(resizeMouseInputHandler);
        }

        titleBar.addMouseMotionListener(moveMouseInputHandler);
        titleBar.addMouseListener(moveMouseInputHandler);

        componentAdapter = new ContentDialogComponentAdapter();
        if (!SwingUtil.isX11() || !SwingUtil.isWsl()) window.getWindow().addComponentListener(componentAdapter);

    }

    /**
     * Dispose the window components and the listeners.
     */
    private void disposeComponents(){

        if (window == null) return;

        componentContainer.remove(content.getComponent());
        componentContainer = null;

        titleBar.removeMouseMotionListener(moveMouseInputHandler);
        titleBar.removeMouseListener(moveMouseInputHandler);
        PanelUI ui = titleBar.getUI();
        ui.uninstallUI(titleBar);
        titleBar = null;
        titleBarButtons = null;
        container = null;

        window.getWindow().removeMouseMotionListener(resizeMouseInputHandler);
        window.getWindow().removeMouseListener(resizeMouseInputHandler);
        window.getWindow().removeComponentListener(componentAdapter);
        window = null;

        resizeMouseInputHandler = null;
        moveMouseInputHandler = null;
    }

    /**
     * Cleanup links to descriptors and resources
     */
    @Override
    public void cleanup() {

        disposeComponents();
        // Clean components
        KeyboardFocusManager.getCurrentKeyboardFocusManager().removePropertyChangeListener("focusOwner", focusListener);
        focusListener = null;

        propertyChangeSupport.removePropertyChangeListeners();
        propertyChangeSupport = null;

        descriptor = null;
        content = null;
        resourceManager = null;

    }

    public void addPropertyChangeListener(String property, PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(property, listener);
    }

    public void propertyChange(PropertyChangeEvent evt) {
        propertyChangeSupport.firePropertyChange(evt);
    }

    protected void initComponents() {
        if (container != null) return;
        propertyChangeSupport = new CleanablePropertyChangeSupport(this);
        descriptor.getCleaner().addCleaner(propertyChangeSupport);

        // Container
        container = (JPanel) resourceManager.createComponent(MyDoggyKeySpace.TOOL_WINDOW_CONTAINER,
                descriptor.getManager().getContext());
        container.setLayout(new ExtendedTableLayout(new double[][]{{TableLayoutConstants.FILL}, {resourceManager.getFloat("toolwindow.title.font.size", 12) + 6,
                TableLayoutConstants.FILL}}, false));
        container.setName("content.container." + content.getId());
        container.setFocusTraversalPolicyProvider(true);
        container.setFocusTraversalPolicy(new ContainerOrderFocusTraversalPolicy());
        container.setFocusCycleRoot(true);
        container.setFocusable(false);

        // Title Bar
        ExtendedTableLayout titleBarLayout = new ExtendedTableLayout(new double[][]{{3, TableLayoutConstants.FILL, 2, -2, 3},
                {1, resourceManager.getFloat("toolwindow.title.font.size", 12) + 4, 1}}, false);
        titleBar = (JPanel) resourceManager.createComponent(
                MyDoggyKeySpace.CONTENT_TITLE_BAR,
                descriptor.getManager().getContext(ContentDescriptor.class, descriptor,
                        ContentContainer.class, this)
        );
        titleBar.setLayout(titleBarLayout);
        titleBar.setName("content.titleBar." + content.getId());
        titleBar.setEnabled(false);
        titleBar.setBorder(null);

        if (descriptor.isIdVisibleOnTitleBar())
            titleBarLayout.setColumn(0, titleBar.getFontMetrics(
                    titleBar.getFont()
            ).stringWidth(resourceManager.getUserString(content.getId())) + 12);

        // Title
        titleLabel = new JLabel(content.getTitle());
        titleLabel.setForeground(resourceManager.getColor(MyDoggyKeySpace.TWTB_TAB_FOREGROUND_UNSELECTED));
        titleLabel.setOpaque(false);
        titleLabel.setFocusable(false);
        titleLabel.setIcon(content.getIcon());
        titleLabel.setFont(titleLabel.getFont().deriveFont(resourceManager.getFloat("toolwindow.title.font.size", 12)));
        titleLabel.setUI(new BasicLabelUI() {

                @Override
                public void update(Graphics g, JComponent c) {
                    if (window.isFocused())
                            titleLabel.setForeground(resourceManager.getColor(MyDoggyKeySpace.TWTB_TAB_FOREGROUND_SELECTED));
                        else
                            titleLabel.setForeground(resourceManager.getColor(MyDoggyKeySpace.TWTB_TAB_FOREGROUND_UNSELECTED));
                    super.update(g, c);
                }


            });
        // Buttons
        titleBarButtons = resourceManager.createInstance(ContentTitleBarButtons.class,
                new DefaultMutableContext(ContentDescriptor.class, descriptor,
                        ContentContainer.class, this
                ));

        // Set TitleBar content
        titleBar.add(titleLabel, "1,1");
        titleBar.add(titleBarButtons.getComponent(), "3,1,right,c");

        // Set Component container
        componentContainer = new JPanel();
        componentContainer.setLayout(new ExtendedTableLayout(new double[][]{{-1}, {-1}}));
        componentContainer.setOpaque(false);
        componentContainer.add(content.getComponent(), "0,0,FULL,FULL");

        if (SwingUtil.isX11()  && SwingUtil.isWsl()) {
            container.setLayout(new BorderLayout());
            container.add(componentContainer, BorderLayout.CENTER);
        } else {
            // Set Container content
            container.add(titleBar, "0,0");
            container.add(componentContainer, "0,1");
        }

        titleBarButtons.setType(ToolWindowType.DOCKED);

    }

    protected void initListeners() {

        focusListener = new FocusOwnerPropertyChangeListener();

        KeyboardFocusManager.getCurrentKeyboardFocusManager().addPropertyChangeListener("focusOwner", focusListener);

    }

    protected class FocusOwnerPropertyChangeListener implements PropertyChangeListener {

        @Override
        public void propertyChange(PropertyChangeEvent evt) {
            if (window == null || !window.getWindow().isVisible() || valueAdjusting)
                return;

            Component component = (Component) evt.getNewValue();
            if (component == null) return;
            if (component instanceof JRootPane) return;

            valueAdjusting = true;

            titleBar.setEnabled(window.isFocused());
            
            valueAdjusting = false;
        }

    }

    protected class ContentDialogComponentAdapter extends ComponentAdapter {

        @Override
        public void componentResized(ComponentEvent e) {
            ContentUI contentUI = content.getContentUI();
            if (contentUI != null) {
                contentUI.setDetachedBounds(e.getComponent().getBounds());
            }
        }

        @Override
        public void componentMoved(ComponentEvent e) {
            ContentUI contentUI = content.getContentUI();
            if (contentUI != null) {
                contentUI.setDetachedBounds(e.getComponent().getBounds());
            }
        }
    }

    protected void enableIdOnTitleBar() {
        TableLayout layout = (TableLayout) titleBar.getLayout();
        layout.setColumn(0,
                titleBar
                        .getFontMetrics(titleBar.getFont())
                        .stringWidth(
                                resourceManager.getUserString(content.getId())
                        )
                        + 12);

        SwingUtil.repaint(titleBar);
    }

    protected void disableIdOnTitleBar() {
        TableLayout layout = (TableLayout) titleBar.getLayout();
        layout.setColumn(0, 3);

        SwingUtil.repaint(titleBar);
    }
}
