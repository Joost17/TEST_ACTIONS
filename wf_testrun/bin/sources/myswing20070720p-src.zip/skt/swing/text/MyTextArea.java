package skt.swing.text;

/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

import javax.swing.*;
import javax.swing.text.Document;

/**
 * @author Santhosh Kumar T
 * @email  santhosh@in.fiorano.com
 */
public class MyTextArea extends JTextArea{
    /*-------------------------------------------------[ Constructors ]---------------------------------------------------*/

    public MyTextArea(){
    }

    public MyTextArea(int rows, int columns){
        super(rows, columns);
    }

    public MyTextArea(String text){
        super(text);
    }

    public MyTextArea(String text, int rows, int columns){
        super(text, rows, columns);
    }

    public MyTextArea(Document doc){
        super(doc);
    }

    public MyTextArea(Document doc, String text, int rows, int columns){
        super(doc, text, rows, columns);
    }

    /*-------------------------------------------------[ Add/Remove Notify ]---------------------------------------------------*/

    public void addNotify(){
        super.addNotify();
        CurrentLineHighlighter.install(this);
    }

    public void removeNotify(){
        super.removeNotify();
        CurrentLineHighlighter.uninstall(this);
    }
}