package skt.swing.search;

/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

import skt.swing.StringConvertor;

import javax.swing.*;
import javax.swing.text.Position;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import java.util.List;
import java.util.ArrayList;

/**
 * @author Santhosh Kumar T
 * @email  santhosh@in.fiorano.com
 */
public class TreeFindAction extends FindAction{

    public TreeFindAction(boolean ignoreCase){
        super(ignoreCase);
    }

    protected boolean changed(JComponent comp, String searchString, Position.Bias bias){
        JTree tree = (JTree)comp;
        boolean startingFromSelection = true;
        int max = tree.getRowCount();
        if (max == 0) return false;
        int increment = 0;
        if(bias!=null)
            increment = (bias == Position.Bias.Forward) ? 1 : -1;
        int startingRow = (tree.getLeadSelectionRow() + increment + max) % max;
        if (startingRow < 0 || startingRow >= tree.getRowCount()) {
            startingFromSelection = false;
            startingRow = 0;
        }

        TreePath path = getNextMatch(tree, searchString, startingRow, bias);
        if (path != null) {
            changeSelection(tree, path);
            return true;
        } else if (startingFromSelection) {
            path = getNextMatch(tree, searchString, 0, bias);
            if (path != null) {
                changeSelection(tree, path);
                return true;
            }
        }
        return false;
    }

    // takes care of modifiers - control
    protected void changeSelection(JTree tree, TreePath path){
        if(controlDown){
            tree.addSelectionPath(path);
        }else
            tree.setSelectionPath(path);
        tree.scrollPathToVisible(path);
    }

    public TreePath getNextMatch(JTree tree, String prefix, int startingRow, Position.Bias bias) {
        if (prefix == null) {
            throw new IllegalArgumentException();
        }
        if (startingRow < 0 || startingRow >= tree.getRowCount()) {
            throw new IllegalArgumentException();
        }
        if(ignoreCase)
            prefix = prefix.toUpperCase();

        // start search from the next/previous element froom the
        // selected element
        int increment = (bias==null || bias == Position.Bias.Forward) ? 1 : -1;

        int row = startingRow;

        // SEARCH ALSO IN INVISIBLE ROWS, ADDED BY OA
        TreePath currentPath = tree.getPathForRow(row);
        List<TreePath> res = new ArrayList<TreePath>(10);
        fillPaths((TreeNode) tree.getModel().getRoot(), res);
        int max = res.size();
        for (int i = 0, n = res.size(); i < n; i++) {
            TreePath p = res.get(i);
            if (!p.equals(currentPath)) continue;
            row = i;
            break;
        }
        do {
            TreePath path = res.get(row);
            StringConvertor convertor = (StringConvertor)comp.getClientProperty(StringConvertor.class);
            String text = convertor!=null
                    ? convertor.toString(path)
                    : tree.convertValueToText(path.getLastPathComponent(), tree.isRowSelected(row),
                            tree.isExpanded(row), true, row, false);

            if(ignoreCase)
                text = text.toUpperCase();

            if (text != null && prefix.length() > 0 && prefix.charAt(0) == '*' && text.contains(prefix.substring(1))) {
                return path;
            }


            if (text.startsWith(prefix)) {
                return path;
            }
            row = (row + increment + max) % max;
            //ADDED FIX BY MS
        } while (!currentPath.equals(res.get(row)));

        return null;
    }

    // ADDED BY OA
    private void fillPaths(TreeNode node, List<TreePath> res) {
        DefaultMutableTreeNode mutableTreeNode = (DefaultMutableTreeNode) node;
        TreePath p = new TreePath(mutableTreeNode.getPath());
        res.add(p);
        if (node.getChildCount() == 0) return;
        for (int i = 0, n = node.getChildCount(); i < n; i++) {
            fillPaths(node.getChildAt(i), res);
        }
    }
}