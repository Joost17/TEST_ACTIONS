package skt.swing.table;

/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

import javax.swing.*;
import javax.swing.event.MouseInputAdapter;
import java.awt.*;
import java.awt.event.MouseEvent;

/**
 * Allows table Rows to be resized without using any row headers
 * just by dragging the horizontal grid lines
 *
 * @author Santhosh Kumar T
 * @email  santhosh@in.fiorano.com
 */
public class TableRowResizer extends MouseInputAdapter{
    public static Cursor resizeCursor = Cursor.getPredefinedCursor(Cursor.N_RESIZE_CURSOR);

    private int mouseYOffset, resizingRow;
    private Cursor otherCursor = resizeCursor;
    private JTable table;

    public TableRowResizer(JTable table){
        this.table = table;
        table.addMouseListener(this);
        table.addMouseMotionListener(this);
    }

    private int getResizingRow(Point p){
        return getResizingRow(p, table.rowAtPoint(p));
    }

    private int getResizingRow(Point p, int row){
        if(row == -1){
            return -1;
        }
        int col = table.columnAtPoint(p);
        if(col==-1)
            return -1;
        Rectangle r = table.getCellRect(row, col, true);
        r.grow(0, -3);
        if(r.contains(p))
            return -1;

        int midPoint = r.y + r.height / 2;
        int rowIndex = (p.y < midPoint) ? row - 1 : row;

        return rowIndex;
    }

    public void mousePressed(MouseEvent e){
        Point p = e.getPoint();

        resizingRow = getResizingRow(p);
        mouseYOffset = p.y - table.getRowHeight(resizingRow);
    }

    private void swapCursor(){
        Cursor tmp = table.getCursor();
        table.setCursor(otherCursor);
        otherCursor = tmp;
    }

    public void mouseMoved(MouseEvent e){
        if((getResizingRow(e.getPoint())>=0)
           != (table.getCursor() == resizeCursor)){
            swapCursor();
        }
    }

    public void mouseDragged(MouseEvent e){
        int mouseY = e.getY();

        if(resizingRow >= 0){
            int newHeight = mouseY - mouseYOffset;
            if(newHeight>0)
                table.setRowHeight(resizingRow, newHeight);
        }
    }
}
