/*
 * GribFile.java  1.0  01/01/2001
 *
 * (C) Benjamin Stark
 * Updated Kjell R�ang, 18/03/2002
 * Updated Richard D. Gonzalez 7 Dec 02
 */

package net.sourceforge.jgrib;

import net.sourceforge.jgrib.util.GribPDSLevelComparator;
import nl.wldelft.util.ByteSize;
import nl.wldelft.util.FileUtils;
import nl.wldelft.util.ObjectArrayUtils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.file.NoSuchFileException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;


/**
 * A class that represents a GRIB file. It consists of a number of records which
 * are represented by <tt>GribRecord</tt> objects.
 *
 * To retrieve a specific record or records, the standard sequence of methods is:
 *    getGridsForType
 *    getZunitsForTypeGrid
 *    getLevelsForTypeGridUnit
 *    getDatesForTypeGridLevel
 *    get2dRecord
 *       or
 *    get3dRecord
 *
 * @author  Benjamin Stark
 * @version 1.0
 */

public class GribFile
{


   /**
    * Array with light records
    */
   private GribRecord[] lightRecords;

   /**
    * Array with grids
    */
   private GribRecordGDS[] grids;

   /**
    * Array with type names
    */
   private String[] typeNames;

   /**
    * Array with descriptions
    */
   private String[] descriptions;


   // Added by Jitka Tacoma, september 2004.  BEGINNING of changes:

    /**
     * Array with type Ids
     */
    private String[] typeIds;

    /**
     * Indication whether the file contains ensemble forecasts
     */
    private boolean isEnsemble = false;

    /**
     * Indication whether the file contains control forecast
     */
    private boolean isControlForecast = false;

    /**
     * Number of ensemble forecasts in the file, incl. the control forecast
     * 0 if no ensemble forecasts.
     */
    private int numberOfEnsembles = 0;
    private int minimumEnsembleNumber = Integer.MAX_VALUE;

    // : END of changes Added by Jitka Tacoma, september 2004


   // *** constructors *******************************************************

   /**
    * Constructs a <tt>GribFile</tt> object from a file.
    *
    * @param filename name of the GRIB file
    *
    * @throws NoSuchFileException if file can not be found
    * @throws IOException           if file can not be opened etc.
    * @throws NoValidGribException  if file is no valid GRIB file
    */
   public GribFile(String filename) throws
           IOException, NotSupportedException, NoValidGribException
   {
      this(FileUtils.newBufferedInputStream(new File(filename), (int) Math.min(new File(filename).length(), 10 * ByteSize.MB)));
   }


   /**
    * Constructs a <tt>GribFile</tt> object from an input stream
    *
    * @param in input stream with GRIB content
    *
    * @throws IOException           if stream can not be opened etc.
    * @throws NoValidGribException  if stream does not contain a valid GRIB file
    */
   public GribFile(InputStream in) throws IOException,
          NotSupportedException, NoValidGribException
   {
      this(new BitInputStream(in));
   }

  /**
    * Constructs a <tt>GribFile</tt> object from a bit input stream
    *
    * @param in bit input stream with GRIB content
    *
    * @throws IOException           if stream can not be opened etc.
    * @throws NoValidGribException  if stream does not contain a valid GRIB file
    */
   public GribFile(BitInputStream in) throws IOException,
          NotSupportedException, NoValidGribException

   {

       try {
             readGribFile(in);
       } finally {
             in.close();
       }
   }



   private void readGribFile(BitInputStream in) throws IOException,
          NotSupportedException, NoValidGribException
   {
      //long start = System.currentTimeMillis();
      Map gridMap = new HashMap();
      List typeList = new ArrayList();
      List descList = new ArrayList();
      List lightRecList = new ArrayList();
      List typeIdsList = new ArrayList();

      /**
      * Initialize the Parameter Tables with the information in the parameter
      * table lookup file.  See GribPDSParamTable for details
      */
      //GribPDSParamTable.readParameterTableLookup(); done in static initializer

      GribRecordIS is = null;             // the indicator section of a record

      while (this.seekHeader(in))
      {
         // Read IS
         is = new GribRecordIS(in);
         int totalBytes = is.getGribLength();

         // Remove IS length
         totalBytes -= is.getISLength();
         byte[] buf = null;

         // Read other records
         GribRecordPDS pds = new GribRecordPDS(in); // read Product Definition Section
         // Remove PDS length
         totalBytes -= pds.getLength();

         GribRecordGDS gds = null;

         if (pds.gdsExists())
         {
//          rdg - changed to use GribGDSFactory class
//            gds = new GribRecordGDS(in);     // read Grid Description Section
            gds = GribGDSFactory.getGDS(in);
            // Remove GDS length
            totalBytes -= gds.getLength();

            // Read rest of bytes
            buf = in.read(totalBytes);
           if (gridMap.containsValue(gds))
            {
               // Get ref alredy in
               gds = (GribRecordGDS) gridMap.get(gds);
            }
            else
            {
               // Put in new
               gridMap.put(gds, gds);
            }
            if (!typeList.contains(pds.getType()))
            {
               typeList.add(pds.getType());
               descList.add(pds.getDescription());
               typeIdsList.add(String.valueOf(pds.getTypeId()));
            }

            // next row changed by OA, use GribRecord directly instead of GribRecordLight, this is slower when not all records are needed
             // but makes in memory compression possible of GribRecordBds.
             // Performance of GribRecordBds is strongly improved for 8, 16, 24 and 32 bits values
             GribRecord grl = new GribRecord(is, pds, gds, new BitInputStream(new ByteArrayInputStream(buf)));
            lightRecList.add(grl);
            //this.records.addElement(buf);               // store record buffer

            // Added by Jitka Tacoma, september 2004.
            if (pds.getIsEnsemble()) {
                this.isEnsemble = true;
            }
            if (pds.getEnsembleNumber() < 1) {
                 this.isControlForecast = true;
            }
            this.minimumEnsembleNumber = Math.min(this.minimumEnsembleNumber, pds.getEnsembleNumber());
            this.numberOfEnsembles = Math.max(this.numberOfEnsembles,pds.getEnsembleNumber());
         }
         else
         {
            // throw new NoValidGribException("GribRecord: No GDS included.");
            // System.err.println("GribRecord: No GDS included.");

            // Skip
            in.skip(totalBytes);
         }

      }

      // Convert to arrays
      this.grids = (GribRecordGDS[]) gridMap.values().toArray(new GribRecordGDS[gridMap.size()]);
      this.typeIds = (String[]) typeIdsList.toArray(new String[typeIdsList.size()]);
      this.typeNames = (String[]) typeList.toArray(new String[typeList.size()]);
      this.descriptions = (String[]) descList.toArray(new String[descList.size()]);
      this.lightRecords = (GribRecord[]) lightRecList.toArray(new GribRecord[lightRecList.size()]);

      if (grids.length == 0) {
         throw new NoValidGribException("Not a valid Grib file.");
      }
      //System.out.println("GribFile: file processed in " +
      //   (System.currentTimeMillis()- start) + " milliseconds");

   }


   /**
    * Get description for type name
    * @param aType type name
    * @return description of type
    */
   public String getDescriptionForType(String aType)
   {
      for (int i = 0; i < typeNames.length; i++)
      {
         if (typeNames[i].equalsIgnoreCase(aType))
         {
            return descriptions[i];
         }
      }
      return null;
   }

   /**
    * Added by Richard Gonzalez 23 Sep 02
    * Get Records whose description matches (aDesc)
    * @return array of GribRecords
    */
   public GribRecord[] getRecordForDescription(String aDesc){
      Set recordSet = new HashSet();

      for (int i = 0; i < lightRecords.length; i++){
         if (lightRecords[i].getPDS().getDescription().equalsIgnoreCase(aDesc)){
            recordSet.add(lightRecords[i]);
         }
      }
      return (GribRecord[]) recordSet.toArray(
                                 new GribRecord[recordSet.size()]);
   }

    /**
     * @param aTypeId type Id
     * @return array of GribRecords
     */
    public GribRecord[] getRecordForType(int aTypeId) {
        Set recordSet = new HashSet();

        for (int i = 0; i < lightRecords.length; i++) {
            if (lightRecords[i].getPDS().getTypeId() == (aTypeId)) {
                recordSet.add(lightRecords[i]);
            }
        }
        return (GribRecord[]) recordSet.toArray(new GribRecord[recordSet.size()]);
    }


   /**
    * Added by Richard Gonzalez 23 Sep 02
    * Get Records for type (variable)
    * @param aType String representing type name
    * @return array of GribRecords
    */
   public GribRecord[] getRecordForType(String aType)
   {
      Set recordSet = new HashSet();

      for (int i = 0; i < lightRecords.length; i++)
      {
         if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType))
         {
            recordSet.add(lightRecords[i]);
         }
      }
      return (GribRecord[]) recordSet.toArray(
                                 new GribRecord[recordSet.size()]);
   }

   /**
    * Get Grids used for type (variable)
    * @param aType type name
    * @return array of grids
    * @deprecated - use getGridsForType - it better reflects the functionality
    */
   public GribRecordGDS[] getGridForType(String aType)
   {
      return getGridsForType(aType);
   }

   /**
    * Get Grids used for type Id (variable Id)
    * @param aTypeId type Id
    * @return array of grids
    */
   public GribRecordGDS[] getGridsForType(int aTypeId)
   {
      Set gdSet = new HashSet();


      for (int i = 0; i < lightRecords.length; i++)
      {
         if (lightRecords[i].getPDS().getTypeId() == aTypeId)
         {
            gdSet.add(lightRecords[i].getGDS());
         }
      }
      return (GribRecordGDS[]) gdSet.toArray(new GribRecordGDS[gdSet.size()]);
   }

    /**
     * Get Grids used for type (variable name)
     *
     * @param aType type name
     * @return array of grids rdg - renamed to better represent functionality
     */
    public GribRecordGDS[] getGridsForType(String aType) {
        Set gdSet = new HashSet();

        for (int i = 0; i < lightRecords.length; i++) {
            if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType)) {
                gdSet.add(lightRecords[i].getGDS());
            }
        }
        return (GribRecordGDS[]) gdSet.toArray(new GribRecordGDS[gdSet.size()]);
    }

    /**
     * <p/>
     * Get level indices for type and grid Can't use the unit string because it may be blank for many types
     *
     * @param aTypeId type Id
     * @param aGDS grid
     * @return array of level indices from table 3
     */
    public int[] getZunitsForTypeGrid(int aTypeId, GribRecordGDS aGDS) {
        Set unitSet = new HashSet();

        for (int i = 0; i < lightRecords.length; i++) {
            if (lightRecords[i].getPDS().getTypeId() == aTypeId &&
                    lightRecords[i].getGDS().equals(aGDS)) {
                unitSet.add(new Integer(lightRecords[i].getPDS().getPDSLevel().getIndex()));
            }
        }
        // parse out the unit indices
        Integer[] ints = (Integer[]) unitSet.toArray(new Integer[unitSet.size()]);
        int[] units = new int[unitSet.size()];
        for (int i = 0; i < ints.length; i++) {
            units[i] = ints[i].intValue();
        }
        return units;
    }
   /**
    * rdg - added this method to distinguish between vertical coordinate types.
    *         e.g. hPa vs. meters vs. layer between hPa surfaces
    *
    * Get level indices for type and grid
    * Can't use the unit string because it may be blank for many types
    * @param aType type name
    * @param aGDS grid
    * @return array of level indices from table 3
    */
   public int[] getZunitsForTypeGrid(String aType, GribRecordGDS aGDS)
   {
      Set unitSet = new HashSet();

      for (int i = 0; i < lightRecords.length; i++){
         if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType) &&
               lightRecords[i].getGDS().equals(aGDS)){
            unitSet.add(new Integer(lightRecords[i].getPDS().getPDSLevel().getIndex()));
         }
      }
      // parse out the unit indices
      Integer[] ints = (Integer[]) unitSet.toArray(new Integer[unitSet.size()]);
      int[] units = new int[unitSet.size()];
      for (int i = 0; i < ints.length; i++){
         units[i] = ints[i].intValue();
      }
      return units;
   }

    /**
     * @param aTypeId type Id
     * @param aGDS grid
     * @param aUnit index of vertical axis units from table 3
     * @return array of GribPDSLevel-s
     */
    public GribPDSLevel[] getLevelsForTypeGridUnit(int aTypeId, GribRecordGDS aGDS,
                                                   int aUnit) {
        Set levelSet = new HashSet();
        List levelValues = new ArrayList(); // used for tracking levels (e.g. 1000mb)
        List levelNames = new ArrayList(); // used for tracking names (e.g. surface, tropopause level)
        Float levelValue;
        String levelName;
        GribPDSLevel level;

        for (int i = 0; i < lightRecords.length; i++) {
            if (lightRecords[i].getPDS().getTypeId() == aTypeId &&
                    lightRecords[i].getGDS().equals(aGDS) &&
                    (lightRecords[i].getPDS().getPDSLevel().getIndex() == aUnit)) {
                // have to use the level alot, get a reference to it
                level = lightRecords[i].getPDS().getPDSLevel();

                // get the numeric value for this level
                levelValue = new Float(level.getValue1());

                // if no value for level (e.g. surface), then check if this type has been added
                if (levelValue.isNaN()) {
                    levelName = level.getName();
                    if (!(levelNames.contains(levelName))) { // if not stored yet, store it
                        levelNames.add(levelName);
                        levelSet.add(lightRecords[i].getPDS().getPDSLevel());
                    }
                } else { // has a numeric value, check if it has been stored
                    if (!(levelValues.contains(level))) {  // if not stored yet, store it
                        levelValues.add(level);
                        levelSet.add(lightRecords[i].getPDS().getPDSLevel());
                    }
                }
            }
        }
        // Sort
        GribPDSLevel[] levels = (GribPDSLevel[]) levelSet.toArray(new GribPDSLevel[levelSet.size()]);
        Arrays.sort(levels, new GribPDSLevelComparator());

        return levels;
    }


   /**
    * rdg - added this method to distinguish between different vertical
    *       coordinate units (e.g. hPa vs. meters).
    * Get levels (sorted) for type and grid and vertical coordinate unit index
    * Using index guards against blank unit strings matching each other
    * @param aType type name
    * @param aGDS grid
    * @param aUnit index of vertical axis units from table 3
    * @return array of GribPDSLevel-s
    */
   public GribPDSLevel[] getLevelsForTypeGridUnit(String aType, GribRecordGDS aGDS,
                                                  int aUnit)
   {
      Set levelSet = new HashSet();
      List levelValues = new ArrayList(); // used for tracking levels (e.g. 1000mb)
      List levelNames = new ArrayList(); // used for tracking names (e.g. surface, tropopause level)
      Float levelValue;
      String levelName;
      GribPDSLevel level;

      for (int i = 0; i < lightRecords.length; i++)
      {
         if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType) &&
             lightRecords[i].getGDS().equals(aGDS) &&
             (lightRecords[i].getPDS().getPDSLevel().getIndex() == aUnit))
         {
            // have to use the level alot, get a reference to it
            level = lightRecords[i].getPDS().getPDSLevel();

            // get the numeric value for this level
            levelValue = new Float(level.getValue1());

            // if no value for level (e.g. surface), then check if this type has been added
            if (levelValue.isNaN()){
               levelName = level.getName();
               if (!(levelNames.contains(levelName))){ // if not stored yet, store it
                  levelNames.add(levelName);
                  levelSet.add(lightRecords[i].getPDS().getPDSLevel());
               }
            }else{ // has a numeric value, check if it has been stored
               if (!(levelValues.contains(level))){  // if not stored yet, store it
                  levelValues.add(level);
                  levelSet.add(lightRecords[i].getPDS().getPDSLevel());
               }
            }
         }
      }
      // Sort
      GribPDSLevel[] levels = (GribPDSLevel[]) levelSet.toArray(new GribPDSLevel[levelSet.size()]);
      Arrays.sort(levels,new GribPDSLevelComparator());

      return levels;
   }


   /**
    * rdg - this is superceded by getLevelsForTypeGridUnit - should be deleted
    * Get levels (sorted) for type and grid
    *
    * @param aType type name
    * @param aGDS grid
    * @return array of forecast time
    * @deprecated - allows ambiguity - use getLevelsForTypeGridUnit instead
    */
   public String[] getLevelsForTypeGrid(String aType, GribRecordGDS aGDS)
   {
      Set gdSet = new HashSet();

      for (int i = 0; i < lightRecords.length; i++)
      {
         if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType) &&
               lightRecords[i].getGDS().equals(aGDS))
         {
            gdSet.add(lightRecords[i].getPDS().getLevel());
         }
      }
      // Sort
      String[] levels = (String[]) gdSet.toArray(new String[gdSet.size()]);
      Arrays.sort(levels);

      return levels;
   }



   /**
    * Get forecast times (sorted) for type and grid.
    * @param aType type name
    * @param aGDS grid
    * @return array of forecast time
    * @deprecated - use same method name that uses a GribPDSLevel vice a string
    */
   public Date[] getDatesForTypeGridLevel(String aType, GribRecordGDS aGDS,
                                          String aLevel)
   {
      ArrayList gdList = new ArrayList();

      for (int i = 0; i < lightRecords.length; i++)
      {
         if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType) &&
               lightRecords[i].getGDS().equals(aGDS) &&
               lightRecords[i].getPDS().getLevel().equals(aLevel))
         {
            gdList.add(lightRecords[i].getPDS().getLocalForecastTime().getTime());
         }
      }
      // Sort
      Date[] dates = (Date[]) gdList.toArray(new Date[gdList.size()]);
      Arrays.sort(dates);



      return dates;
   }

   /**
    * rdg - an override of the method passing a GribPDSLevel, vice a string for a level
    * Get forecast times (sorted) for type and grid
    * @param aType type name
    * @param aGDS grid
    * @return array of forecast time
    */
   public Date[] getDatesForTypeGridLevel(String aType, GribRecordGDS aGDS,
                                          GribPDSLevel aLevel)
   {
      ArrayList dateList = new ArrayList();

      for (int i = 0; i < lightRecords.length; i++)
      {
         if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType) &&
            lightRecords[i].getGDS().equals(aGDS) &&
            lightRecords[i].getPDS().getPDSLevel().equals(aLevel))
         {
            dateList.add(lightRecords[i].getPDS().getLocalForecastTime().getTime());
         }
      }
      // Sort
      Date[] dates = (Date[]) dateList.toArray(new Date[dateList.size()]);
      Arrays.sort(dates);

      return dates;
   }

    /**
     * Added by Jitka Tacoma, september 2004:
     * Get sorted forecast times  for type , grid , level and ensemble number
     *
     * @param aType type name
     * @param aGDS grid geometry
     * @param aLevel level
     * @param  ensembleNumber ensemble number
     * @return array of forecast time
     */
    public Date[] getDatesForTypeGridLevel(String aType, GribRecordGDS  aGDS,
                                           GribPDSLevel aLevel, int ensembleNumber) {
        ArrayList dateList = new ArrayList();

        for (int i = 0; i < lightRecords.length; i++) {
            if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType) &&
                    lightRecords[i].getGDS().equals(aGDS) &&
                    lightRecords[i].getPDS().getPDSLevel().equals(aLevel) &&
                    lightRecords[i].getPDS().getEnsembleNumber() == ensembleNumber)
            {
                dateList.add(lightRecords[i].getPDS().getLocalForecastTime().getTime());
            }
        }
        // Sort
        Date[] dates = (Date[]) dateList.toArray(new Date[dateList.size()]);
        Arrays.sort(dates);
        dates = ObjectArrayUtils.removeDuplicates(dates);

        return dates;
    }

    /**
     * Added by Jitka Tacoma, september 2004: Get sorted forecast times  for type , grid , level and ensemble number
     *
     * @param aTypeId type Id
     * @param aGDS grid geometry
     * @param aLevel level
     * @param ensembleNumber ensemble number
     * @return array of forecast time
     */
    public Date[] getDatesForTypeGridLevel(int aTypeId, GribRecordGDS aGDS,
                                           GribPDSLevel aLevel, int ensembleNumber) {
        ArrayList dateList = new ArrayList();

        for (int i = 0; i < lightRecords.length; i++) {
            if (lightRecords[i].getPDS().getTypeId() == aTypeId &&
                    lightRecords[i].getGDS().equals(aGDS) &&
                    lightRecords[i].getPDS().getPDSLevel().equals(aLevel) &&
                    lightRecords[i].getPDS().getEnsembleNumber() == ensembleNumber) {
                dateList.add(lightRecords[i].getPDS().getLocalForecastTime().getTime());
            }
        }
        // Sort
        Date[] dates = (Date[]) dateList.toArray(new Date[dateList.size()]);
        Arrays.sort(dates);
        dates = ObjectArrayUtils.removeDuplicates(dates);

        return dates;
    }
   /**
    * Get a specified grid record
    * @param aType type name
    * @param aGDS  grid
    * @param aDate forecast date
    * @return
    */
   public GribRecord getRecord(String aType, GribRecordGDS aGDS, String aLevel,
                               Date aDate)
         throws IOException, NoValidGribException, NotSupportedException
   {
      GribRecord grl = null;

      for (int i = 0; i < lightRecords.length; i++)
      {
         if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType) &&
               lightRecords[i].getGDS().equals(aGDS) &&
               lightRecords[i].getPDS().getLevel().equals(aLevel) &&
               lightRecords[i].getPDS().getLocalForecastTime().getTime().equals(aDate))
         {
            grl = lightRecords[i];
            break;
         }
      }
      if (grl != null)
      {
         return grl;
      }
      else
      {
       return null;
   }
   }

    /**
     * Get grid records for the arguments as specified
     * @param aTypeId type (ie parameter) id
     * @param aGDS  grid definition
     * @param aLevel level
     * @return  GribRecord[]
     */
    public GribRecord[] getRecord(int aTypeId, GribRecordGDS aGDS, String aLevel)
             throws IOException, NoValidGribException, NotSupportedException
    {

          List list = new ArrayList();
          for (int i = 0; i < lightRecords.length; i++)
          {
             if (lightRecords[i].getPDS().getTypeId() == aTypeId &&
                   lightRecords[i].getGDS().equals(aGDS) &&
                   lightRecords[i].getPDS().getLevel().equals(aLevel))
             {
                GribRecord grl = lightRecords[i];
                list.add(grl);
             }
          }
         return (GribRecord[]) list.toArray(new GribRecord[list.size()]);

   }




    /**
     * Added by Jitka Tacoma, september 2004:
     * Get a specified grid record for type, grid geometry, level, date and ensemble number.
     * If ensemble number is 0 the control forecast  wil be returned.
     *
     * @param aGDS grid
     * @param aLevel level
     * @param aDate forecast date
     * @param ensembleNumber ensemble number
     * @return
     */
    public GribRecord getRecord(int aTypeId, GribRecordGDS aGDS, String aLevel,
                                Date aDate, int ensembleNumber)
            throws IOException, NoValidGribException, NotSupportedException {



        GribRecord grl = null;

        for (int i = 0; i < lightRecords.length; i++) {
            if (lightRecords[i].getPDS().getTypeId() == aTypeId &&
                    lightRecords[i].getGDS().equals(aGDS) &&
                    lightRecords[i].getPDS().getLevel().equals(aLevel) &&
                    lightRecords[i].getPDS().getLocalForecastTime().getTime().equals(aDate) &&
                    lightRecords[i].getPDS().getEnsembleNumber() == ensembleNumber ) {
                grl = lightRecords[i];
                break;
            }
        }
        if (grl != null) {
            return grl;
        } else {
            return null;
        }
    }
   /**
    * rdg - added this method to work with refined methods.  Also made name more
    *       specific to what you are getting.
    * Get a specified grid record
    * @param aType parameter type name
    * @param aGDS  grid
    * @param aLevel level
    * @param aDate forecast date
    * @return - a GribRecord for a single level of a parameter
    */
   public GribRecord get2dRecord(String aType, GribRecordGDS aGDS,
                                 GribPDSLevel aLevel, Date aDate)
         throws IOException, NoValidGribException, NotSupportedException
   {
      GribRecord grl = null;

      for (int i = 0; i < lightRecords.length; i++)
      {
         if (lightRecords[i].getPDS().getType().equalsIgnoreCase(aType) &&
               lightRecords[i].getGDS().equals(aGDS) &&
               lightRecords[i].getPDS().getPDSLevel().equals(aLevel) &&
               lightRecords[i].getPDS().getLocalForecastTime().getTime().equals(aDate))
         {
            grl = lightRecords[i];
            break;
         }
      }
      if (grl != null)
      {
         return grl;
      }
      else
      {
         return null;
      }
   }

   /**
    * rdg - added this method to work with refined methods.  Also made name more
    *       specific to what you are getting.
    * Get a specified grid record
    * @param aType parameter type name
    * @param aGDS  grid
    * @param levels  levels to be retrieved - should already be sorted
    * @param aDate forecast date
    * @return - an array of GribRecord-s representing a volume of a parameter
    */
   public GribRecord[] get3dRecord(String aType, GribRecordGDS aGDS,
                                   GribPDSLevel[] levels, Date aDate)
         throws IOException, NoValidGribException, NotSupportedException
   {
      GribRecord[] records = new GribRecord[levels.length];
      GribRecord grl = null;

      for (int z = 0; z < levels.length; z++){

         for (int i = 0; i < lightRecords.length; i++){
            if (lightRecords[i].getGDS().equals(aGDS) &&
                  lightRecords[i].getPDS().getType().equalsIgnoreCase(aType) &&
                  lightRecords[i].getPDS().getPDSLevel().equals(levels[z]) &&
                  lightRecords[i].getPDS().getLocalForecastTime().getTime().equals(aDate))
            {
               grl = lightRecords[i];
               break;
            }
         }
         if (grl != null){
            records[z] = grl;
         }else{
            return null;
         }
      }
      return records;
   }

   private boolean seekHeader(BitInputStream in)
   {

      // seek header
      try
      {
         while (in.available() > 0)
         {
            // code must be "G" "R" "I" "B"
            int ui8 = in.readUI8();
            if (ui8 == (int) 'G' && in.readUI8() == (int) 'R'
                  && in.readUI8() == (int) 'I' && in.readUI8() == (int) 'B')
               return true;
         }
      }
      catch (IOException ioe)
      {
         // do nothing
      }
      return false;
   }

   /**
    * Get a specific GRIB record of this GRIB file as <tt>GribRecord</tt> object.
    *
    * @param i number of GRIB record, first record is number 1
    *
    * @return GRIB record object
    *
    * @throws NoSuchElementException if record number does not exist
    * @throws IOException            if record can not be opened etc.
    * @throws NoValidGribException   if record is no valid GRIB record
    * @throws NotSupportedException  if JGrib doesn't yet support the operation
    */
   public GribRecord getRecord(int i) throws NoSuchElementException,
         IOException, NoValidGribException, NotSupportedException
   {

      if (i <= 0 || i > this.lightRecords.length)
         throw new NoSuchElementException("GribFile: No such record (" + i + ").");

      // Changed by Peter Gylling Peg@fomfrv.dk 2002-04-16
      // from this line
      // return new GribRecord(lightRecords[i]);
      return lightRecords[i - 1];
      //return new GribRecord((byte[]) this.records.elementAt(i - 1));
   }

   /**
    * Get type names
    * @return array with names
    */
    public String[] getTypeIds() {
        return typeIds;
    }

    /**
    * Get type names
    * @return array with names
    */
   public String[] getTypeNames()
   {
      return typeNames;
   }

   /**
    * Get Light GRIB records
    * @return Array with Light Grib Records
    */
   public GribRecord[] getLightRecords()
   {
      return lightRecords;
   }

   /**
    * Get get grids
    * @return array with grids
    */
   public GribRecordGDS[] getGrids()
   {
      return grids;
   }


   /**
    * Get the number of records this GRIB file contains.
    *
    * @return number of records in this GRIB file
    */
   public int getRecordCount()
   {
      return this.lightRecords.length;
   }

    /**
     * Get the indication whether there are ensemble forecasts in the file
     * @return boolean
     */
    public boolean getIsEnsemble() {
        return this.isEnsemble;
    }

    /**
     * Get the indication whether there is a control forecast in the file
     * @return boolean
     */
    public boolean getIsControlForecast() {
        return this.isControlForecast;
    }

    /**
     * Get the indication whether there is a control forecast in the file
     *
     * @return boolean
     */
    public int getNumberOfEnsembles() {
        return this.numberOfEnsembles;
    }

    public int getMinimumEnsembleNumber() {
        return this.minimumEnsembleNumber;
    }

   /**
    * Print out overview of GRIB file content.
    *
    * @param out print stream the output is written to
    *
    * @throws IOException            if a record can not be opened etc.
    * @throws NoValidGribException   if a record is no valid GRIB record
    * @throws NotSupportedException  if JGrib doesn't support something yet
    */
   public void listRecords(PrintStream out) throws IOException,
          NoValidGribException, NotSupportedException
   {
      for (int i = 0; i < this.lightRecords.length; i++)
         out.println("(" + (i + 1) + ") " +
              lightRecords[i]);
   }

   /**
    * Method added by Richard Gonzalez 23 Sep 02.
    *
    * Print out listing of parameters in GRIB file.
    *
    * @param out print stream the output is written to
    *
    */
   public void listParameters(PrintStream out)
   {
      String currentParam = null;
      String oldParam = null;
      int recordCount;

      // determine how many GribRecords are stored
      recordCount = this.getRecordCount();
      System.out.println("GribFile reports " + recordCount + " records,");

      // Get light grib reccords
      GribRecord[] gribLight = this.getLightRecords();

      System.out.print("   PDS records [record number] are:");
      for (int i=0; i < recordCount; i++){
         GribRecordPDS gribPDS = gribLight[i].getPDS();
         currentParam = gribPDS.getDescription();
         if (currentParam == oldParam){ // put same parameter on the same line
            // one added because records start at 1
            System.out.print(";" + gribPDS.getLevel()+ "[" + (i+1) + "]");
         }
         else{ // start a new line
            System.out.println();
            System.out.print("       " + currentParam + " at level(s): ");
            oldParam = currentParam;
            System.out.print(gribPDS.getLevel() + "[" + (i+1) + "]");
         }
      }
   }

   /**
    * Get a string representation of the GRIB file.
    *
    * @return NoValidGribException   if record is no valid GRIB record
    */
   public String toString(){
      return "GRIB file (" + this.lightRecords.length + " records)";
   }

}


