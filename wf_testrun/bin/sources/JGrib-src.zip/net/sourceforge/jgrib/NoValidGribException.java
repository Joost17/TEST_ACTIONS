/*
 * NoValidGribException.java  1.0  01/01/2001
 *
 * (C) Benjamin Stark
 */

package net.sourceforge.jgrib;


/**
 * A class that represents an exception during GRIB file operations.
 *
 * @author  Benjamin Stark
 * @version 1.0
 */

public class NoValidGribException extends Exception
{

   /**
    * Construct a new Exception with message <tt>msg</tt>.
    *
    * @param msg error message
    */
   public NoValidGribException(String msg)
   {

      super(msg);
   }
}

