/*
 * GribRecordBDS.java  1.0  01/01/2001
 *
 * (C) Benjamin Stark
 */

package net.sourceforge.jgrib;

import nl.wldelft.util.BinaryUtils;
import nl.wldelft.util.BooleanArrayUtils;
import nl.wldelft.util.ByteArrayUtils;
import nl.wldelft.util.CompressUtils;
import nl.wldelft.util.FloatArrayUtils;
import nl.wldelft.util.NumberType;

import java.io.IOException;
import java.nio.ByteOrder;
import java.util.zip.DataFormatException;


/**
 * A class representing the binary data section (BDS) of a GRIB record.
 *
 * @author  Benjamin Stark
 * @version 1.0
 */

public class GribRecordBDS
{

    /**
     * Length in bytes of this BDS.
     */
    protected int length;

   /**
    * Binary scale factor.
    */
   protected int binscale;

   /**
    * Reference value, the base for all parameter values.
    */
   protected float refvalue;

   /**
    * Number of bits per value.
    */
   protected int numbits;

   /**
    * Array of parameter values.
    */
   protected float[] values;

    /**
     * Array of parameter bytes. Not null when the number of bits
     * is a whole number of bytes.
     */
    protected byte[] compressedBytes;


    /**
    * Minimal parameter value in grid.
    */
   protected float minvalue = Float.MAX_VALUE;

   /**
    * Maximal parameter value in grid.
    */
   protected float maxvalue = -Float.MAX_VALUE;

   /**
    * rdg - added this to prevent a divide by zero error if variable data empty
    *
    * Indicates whether the BMS is represented by a single value
    *   -  Octet 12 is empty, and the data is represented by the reference value.
    */
    protected boolean isConstant = false;


    // support for missing values added by OA
    // support for store the values compressed in memory
    // added by oa
    private float ref = Float.NaN;
    private float scale = Float.NaN;
    private int nrCells;
    private NumberType compressedNumberType = null;
    private boolean disposed = false;

    // *** constructors *******************************************************

   /**
    * Constructs a <tt>GribRecordBDS</tt> object from a bit input stream.
    * A bit map which indicates grid points where no parameter value is
    * defined is not available.
    *
    * @param in           bit input stream with PDS content
    * @param decimalscale the exponent of the decimal scale
    *
    * @throws IOException           if stream can not be opened etc.
    * @throws NoValidGribException  if stream contains no valid GRIB file
    */
   public GribRecordBDS(BitInputStream in, int decimalscale, GribRecordGDS gds)
         throws IOException, NoValidGribException, NotSupportedException
   {
      this(in, decimalscale, null, gds);
   }


   /**
    * Constructs a <tt>GribRecordBDS</tt> object from a bit input stream.
    * A bit map indicates the grid points where no parameter value is defined.
    *
    * @param in           bit input stream with PDS content
    * @param decimalscale the exponent of the decimal scale
    * @param bms          bit map section of GRIB record
    *
    * @throws IOException           if stream can not be opened etc.
    * @throws NoValidGribException  if stream contains no valid GRIB file
    */
   public GribRecordBDS(BitInputStream in, int decimalscale, GribRecordBMS bms, GribRecordGDS gds)
         throws IOException, NotSupportedException
   {
       int[] data = in.readUI8(11);
       int unusedbits;

       // octets 1-3 (section length)
       this.length = Bytes2Number.uint3(data[0], data[1], data[2]);

       // octet 4, 1st half (packing flag)
       if ((data[3] & 240) != 0)
           throw new NotSupportedException("GribRecordBDS: No other flag " +
                   "(octet 4, 1st half) than 0 (= simple packed floats as " +
                   "grid point data) supported yet in BDS section.");

       // octet 4, 2nd half (number of unused bits at end of this section)
       unusedbits = data[3] & 15;

       // octets 5-6 (binary scale factor)
       this.binscale = Bytes2Number.int2(data[4], data[5]);

       // octets 7-10 (reference point = minimum value)
       this.refvalue = Bytes2Number.float4(data[6], data[7], data[8], data[9]);

       // octet 11 (number of bits per value)
       this.numbits = data[10];
       if (this.numbits == 0)
           isConstant = true;

       // *** read values ************************************************************

       ref = (float) (Math.pow(10.0, -decimalscale) * this.refvalue);
       scale = (float) (Math.pow(10.0, -decimalscale) * Math.pow(2.0, this.binscale));

       if (isConstant) {
           this.maxvalue = ref;
           this.minvalue = ref;
           this.nrCells = 0;
           return;
       }

       boolean[] bitmap;
       int nrActiveCells;
       if (bms == null) {
           bitmap = null;
           this.nrCells = ((this.length - 11) * 8 - unusedbits) / this.numbits;
           nrActiveCells = nrCells;
           int gdsCellCount = gds.getGridNX() * gds.getGridNY();
           if (gdsCellCount != nrCells) {
               // HACK FOR TAIWAN, correct wrong number of cells specified bms
               System.out.println("Incorrect nr of cells in grib " + nrCells + " instead of  " + gdsCellCount);
               nrCells = gdsCellCount;
               nrActiveCells = gdsCellCount;
           }
       } else {
           bitmap = bms.getBitmap();
           this.nrCells = bitmap.length;
           nrActiveCells = BooleanArrayUtils.countValue(bitmap, true);
       }

       byte[] bytes;
       if (this.numbits % 8 == 0) {
           compressedNumberType = NumberType.getUnsignedIntType(this.numbits);
           bytes = in.read(nrActiveCells * compressedNumberType.getSize());
           float[] values = new float[nrActiveCells];
           BinaryUtils.copy(bytes, 0, bytes.length, values,
                   0, values.length, compressedNumberType, ref, scale, (int) compressedNumberType.getDefaultMissingValue(), ByteOrder.BIG_ENDIAN);
           minvalue = FloatArrayUtils.minSkipNaN(values);
           maxvalue = FloatArrayUtils.maxSkipNaN(values);

           if (FloatArrayUtils.containsNaN(values)) {
               // the value should not contain a missing value
               float realValue = ref + compressedNumberType.getDefaultMissingValue() * scale;
               FloatArrayUtils.replaceNaN(values, realValue);
               if (realValue < minvalue) minvalue = realValue;
               if (realValue > maxvalue) maxvalue = realValue;
               long minIntValue = (long) Math.floor(minvalue / scale);
               long maxIntValue = (long) Math.ceil(maxvalue / scale);
               compressedNumberType = NumberType
                       .getBestSuitableIntType(NumberType.UNSIGNED_INTEGER_TYPES, minIntValue, maxIntValue);
               ref = compressedNumberType.requiredOffset(minIntValue, maxIntValue) * scale;
               bytes = new byte[nrActiveCells * compressedNumberType.getSize()];
               BinaryUtils.copy(values, 0, values.length, bytes, 0, bytes.length, compressedNumberType, ref, scale, (int) compressedNumberType.getDefaultMissingValue(), ByteOrder.BIG_ENDIAN);
           }
       } else {
           float[] values = new float[nrActiveCells];
           for (int i = 0; i < values.length; i++) {
               long ubits = in.readUBits(this.numbits);
               float value = ref + scale * ubits;
               if (value > this.maxvalue)
                   this.maxvalue = value;
               if (value < this.minvalue)
                   this.minvalue = value;

               values[i] = value;
           }

           long minIntValue = (long) Math.floor(minvalue / scale);
           long maxIntValue = (long) Math.ceil(maxvalue / scale);
           compressedNumberType = NumberType
                   .getBestSuitableIntType(NumberType.UNSIGNED_INTEGER_TYPES, minIntValue, maxIntValue);
           ref = compressedNumberType.requiredOffset(minIntValue, maxIntValue) * scale;
           bytes = new byte[nrActiveCells * compressedNumberType.getSize()];
           BinaryUtils.copy(values, 0, values.length, bytes, 0, bytes.length,
                   compressedNumberType, ref, scale, (int) compressedNumberType.getDefaultMissingValue(), ByteOrder.BIG_ENDIAN);

       }
       if (bitmap != null) bytes = expandBytes(bitmap, bytes);

       int maxCompressedSize = CompressUtils.getMaxCompressedSize(
               bytes.length, compressedNumberType.getSize());
       this.compressedBytes = new byte[maxCompressedSize];
       int compressedSize = CompressUtils.compress(bytes, 0, bytes.length, this.compressedBytes,
               0, this.compressedBytes.length, compressedNumberType.getSize());
       this.compressedBytes = ByteArrayUtils.resize(this.compressedBytes, compressedSize);

       this.values = null;

   }

    private byte[] expandBytes(boolean[] bitmap, byte[] bytes) {
        assert bitmap != null;
        assert bytes.length % compressedNumberType.getSize() == 0;
        byte[] res = new byte[nrCells * compressedNumberType.getSize()];
        byte[] missingBytes = new byte[compressedNumberType.getSize()];
        BinaryUtils.copy(new int[] {(int) compressedNumberType.getDefaultMissingValue()}, 0, 1,
                missingBytes, 0, missingBytes.length, compressedNumberType, 0);
        for (int i = 0, k = 0, l = 0; i < nrCells; i++) {
            if (bitmap[i]) {
                for (int j = 0; j < compressedNumberType.getSize(); j++) {
                    res[k++] = bytes[l++];
                }
            } else {
                for (int j = 0; j < compressedNumberType.getSize(); j++) {
                    res[k++] = missingBytes[j];
                }
            }
        }
        return res;
    }

    // *** public methods *********************************************************

   /**
    * Get the length in bytes of this section.
    *
    * @return length in bytes of this section
    */
   public int getLength()
   {

      return this.length;
   }


   /**
    * Get the binary scale factor.
    *
    * @return binary scale factor
    */
   public int getBinaryScale()
   {

      return this.binscale;
   }

   /**
    * Get whether this BDS is single valued
    *
    * @return isConstant
    */
   public boolean getIsConstant()
   {
      return this.isConstant;
   }

   /**
    * Get the reference value all data values are based on.
    *
    * @return reference value
    */
   public float getReferenceValue()
   {
      return this.refvalue;
   }


   /**
    * Get number of bits used per parameter value.
    *
    * @return number of bits used per parameter value
    */
   public int getNumBits()
   {
      return this.numbits;
   }


   /**
    * Get data/parameter values as an array of float.
    *
    * @return  array of parameter values
    */
   public float[] getValues()
   {
       // added by OA, disposed
       if (disposed)
           throw new IllegalStateException("grib record is disposed: " + this);

       if (isConstant)
           throw new IllegalStateException("grib record contains constant value: " + this);

       // added by OA, expand values on the fly
       if (this.values != null) return this.values;
       assert this.compressedBytes!= null;

       try {
           int uncompressedSize = CompressUtils.getUncompressedSize(
                   this.compressedBytes, 0, this.compressedBytes.length);
           byte[] bytes = new byte[uncompressedSize];
           CompressUtils.expand(this.compressedBytes, 0, this.compressedBytes.length, bytes,
                   0, bytes.length);

           float[] res = new float[nrCells];
           BinaryUtils.copy(bytes, 0, bytes.length, res, 0, res.length, compressedNumberType, ref, scale, (int) compressedNumberType.getDefaultMissingValue(), ByteOrder.BIG_ENDIAN);
           this.compressedBytes = null;
           return res;
       } catch (DataFormatException e) {
           throw new RuntimeException(); // compressed bytes never written to file, so can not be damaged
       }
   }

   /**
    * Get data/parameter value as a float.
    *
    * @return  array of parameter values
    */
   public float getValue(int index) throws NoValidGribException
   {
       // added by OA, expand values and keep them uncompressed
       if (disposed)
            throw new IllegalStateException("grib record is disposed: " + this);

       if (isConstant) return ref;

       if (this.values == null) this.values = getValues();
      if (index >=0 && index < values.length){
         return this.values[index];
      }else{
         throw new NoValidGribException("GribRecordBDS: Array index out of bounds");
      }
   }


   /**
    * Get minimum value
    * @return mimimum value
    */
   public float getMinValue()
   {
      return minvalue;
   }

   /**
    * Get maximum value
    * @return maximum value
    */
   public float getMaxValue()
   {
      return maxvalue;
   }


   /**
    * Get a string representation of this BDS.
    *
    * @return string representation of this BDS
    */
   public String toString()
   {
      return "    BDS section:" + '\n' +
            "        min/max value: " + this.minvalue + " " + this.maxvalue + "\n" +
            "        ref. value: " + this.refvalue + "\n" +
            "        is a constant: " + this.isConstant + "\n" +
            "        bin. scale: " + this.binscale + "\n" +
            "        num bits: " + this.numbits;
   }

    // next getters added by OA to use the compressed bytes directly
    public float getRef() {
        return ref;
    }

    public float getScale() {
        return scale;
    }

    public int getNumbits() {
        return numbits;
    }

    public int getNrCells() {
        return nrCells;
    }

    public byte[] getCompressedBytes() {
        return compressedBytes;
    }

    public NumberType getCompressedNumberType() {
        return compressedNumberType;
    }

    // added by OA to free the memory before the GribFile is unreferenced
    public void dispose() {
        this.values = null;
        this.compressedBytes = null;
        this.disposed = true;
    }
}

