/*
 * GribInfo.java  1.0  01/01/2001
 *
 * (C) Benjamin Stark
 * Updated Kjell R�ang, 18/03/2002
 */

package net.sourceforge.jgrib;

import java.util.Calendar;
import java.util.Date;


/**
 * A class that prints some info about a record of a GRIB file.
 *
 * @author  Benjamin Stark
 * @version 1.0
 * @deprecated - due to changes in JGrib, this may not work properly - use JGribDemo instead
 */

public class GribInfo
{

   private static String usage = "usage: GribInfo gribfile recordnumber [recordnumber ...]";

   public static void main(String[] args)
   {

      try
      {

         // usage
         if (args.length <= 1)
            System.err.println(usage);

         else
         {

            long t1 = System.currentTimeMillis();
            GribFile grib = new GribFile(args[0]);
            long t2 = System.currentTimeMillis();
            System.err.println("Delta time peek file: "+(double)((t2-t1)/1000.0)+" s");

            // Get types
            String[] types = grib.getTypeNames();
            String type = types[0];

            // Get description
            String para = grib.getDescriptionForType(type);

            // Get grid for type name
            GribRecordGDS[] grids = grib.getGridForType(type);
            GribRecordGDS grid = grids[0];

            // Get levels for type and grid
            String[] levels = grib.getLevelsForTypeGrid(type, grid);
            String level = levels[0];

            // Get times for type, grid and level
            Date[] dates = grib.getDatesForTypeGridLevel(type, grid, level);
            Date date = dates[0];

            // Print all dates
            for (int i=0; i<dates.length; i++)
            {
               System.err.println("i= "+i+" date = "+dates[i]);
            }

            // Get record
            GribRecord record = grib.getRecord(type, grid, level, date);
            System.err.println(" (" + record.getType() + "):\n\n" + record + "\n");

            for (int i = 1; i < args.length; i++)
            {

               int recordnumber = Integer.parseInt(args[i]);
               record = grib.getRecord(recordnumber);

               // Get data
               float[] data = record.getBDS().getValues();
               // Time
               Calendar cal = record.getTime();
               System.err.println("Date: " + cal.getTime());
               // Level
               level = record.getLevel();
               // Type
               type = record.getType();
               // Paramter
               para = record.getDescription();
               // Unit
               String unit = record.getUnit();

               // Grid
               grid = record.getGDS();
               // Grid
               double[] coords = grid.getGridCoords();


               System.err.println("\nRecord " + args[i] +
                     " (" + record.getType() +
                     "):\n\n" + record + "\n");
            }
         }
      }
      catch (NumberFormatException e)
      {
         System.err.println("NumberFormatException: " + e.getMessage());
         System.err.println(usage);
      }
      catch (Exception e)
      {
         System.err.println("Exception: " + e.getMessage());
      }

   }

}

