/**
 * Created by IntelliJ IDEA.
 * User: Kjell R�ang
 * Date: 15.mar.02
 */
package net.sourceforge.jgrib;

public class GribRecordLight
{
   /**
     * The indicator section.
     */
    protected GribRecordIS is;

    /**
     * The product definition section.
     */
    protected GribRecordPDS pds;

    /**
     * The grid geometry section.
     */
    protected GribRecordGDS gds;

   /**
    * Array with bytes
    */
   protected byte[] buf;

   /**
    *
    * @param aIs IS section
    * @param aPds PDS section
    * @param aGds GDS section
    * @param aBuf buffer with rest of data
    */
   public GribRecordLight(GribRecordIS aIs, GribRecordPDS aPds, GribRecordGDS aGds, byte[] aBuf)
   {
      is = aIs;
      pds = aPds;
      gds = aGds;
      buf = aBuf;
   }

   /**
    *  Get Information record
    * @return an IS record
    */
   public GribRecordIS getIS()
   {
      return is;
   }

   /**
    * Get Product Definition record
    * @return a PDS record
    */
   public GribRecordPDS getPDS()
   {
      return pds;
   }

   /**
    * Get grid geometry record
    * @return a
    */
   public GribRecordGDS getGDS()
   {
      return gds;
   }

   /**
    * Get buffer with bds and bms
    * @return
    */
   public byte[] getBuf()
   {
      return buf;
   }
}
