/**
 * GribPDSLevel.java  1.0  08/01/2002
 *
 * Newly created, based on GribTables class.  Moved level specific
 * functionality to this class.
 * Performs operations related to loading level information from Table 3.
 * Corrected the octet numbers.
 *
 * Author: Capt Richard D. Gonzalez
 */

package net.sourceforge.jgrib;

/**
 * A class containing static methods which deliver descriptions and names of
 * parameters, levels and units for byte codes from GRIB records.
 */

public class GribPDSLevel
{

   /**
    * Index number from table 3 - can be used for comparison even if the
    * description of the level changes
    */
   private int index;

   /**
    * Name of the vertical coordinate/level
    *
    */
   private String name=null;

   /**
    * Value of PDS octet10 if separate from 11, otherwise value from octet10&11
    */
   private float value1;

   /**
    * Value of PDS octet11
    */
   private float value2;

   /**
    * Stores a short name of the level - same as the string "level" in the original
    * GribRecordPDS implementation
    */
   private String level = "";

   /**
    * Stores a descriptive name of the level
    * GribRecordPDS implementation
    */
   private String description = "";

   /**
    * Stores the name of the level - same as the string "level" in the original
    * GribRecordPDS implementation
    */
   private String units = "";

   /**
    * Stores whether this is (usually) a vertical coordinate for a single layer
    *  (e.g. surface, tropopause level) or multiple layers (e.g. hPa, m AGL)
    * Aids in deciding whether to build 2D or 3D grids from the data
    */
   private boolean isSingleLayer = true;

   /**
    * Indicates whether the vertical coordinate increases with height.
    * e.g. false for pressure and sigma, true for height above ground or if unknown
    */
   private boolean isIncreasingUp = true;

   /**
    * True if a numeric values are used for this level (e.g. 1000 mb)
    * False if level doesn't use values (e.g. surface).
    * Basically indicates whether you will be able to get a value for this level.
    */
   private boolean isNumeric=false;


   /**
    * Constructor.  Creates a GribPDSLevel based on octets 10-12 of the PDS.
    * Implements tables 3 and 3a.
    *
    * @param pds10 part 1 of level code
    * @param pds11 part 2 of level code
    * @param pds12 part 3 of level code
    *
    * @return description of the level
    *
    * rdg - Still needs refinement - not consistent in application - table not complete
    * Should eventually implement externally, like Parameter Tables, to allow for changes
    */
   public GribPDSLevel(int pds10, int pds11, int pds12)
   {

      int pds1112 = pds11 << 8 | pds12;
      this.index = pds10;
      switch (index)
      {
         case 1:
            name = description = level ="surface";
            break;
         case 2:
            name = description = level = "cloud base level";
            break;
         case 3:
            name = description = level = "cloud top level";
            break;
         case 4:
            name = description = level = "0 degree isotherm level";
            break;
         case 5:
            name = description = level = "condensation level";
            break;
         case 6:
            name = description = level = "maximum wind level";
            break;
         case 7:
            name = description = level = "tropopause level";
            break;
         case 8:
            name = description = level = "nominal atmosphere top";
            break;
         case 9:
            name = description = level = "sea bottom";
            break;
         case 20:
            name = "Isothermal level";
            value1 = pds1112;
            units = "K";
            isNumeric = true;
            level = value1 + " K";
            description = "Isothermal level at " + value1/100 + units;
            break;
         case 100:
            name = "P";
            value1 = pds1112;
            units = "hPa";
            isNumeric = true;
            isIncreasingUp = false;
            isSingleLayer = false;
            level = pds1112 + " " + units;
            description = "pressure at " + value1 + " " + units;
            break;
         case 101:
            name = "layer between two isobaric levels";
            value1 = pds11*10; // convert from kPa to hPa - who uses kPa???
            value2 = pds12*10;
            units = "hPa";
            level = value1 + " - " + value2 + " " + units;
            description = "layer between " + value1 + " and " + value2 + " " + units;
            break;
         case 102:
            name = description = level = "mean sea level";
            break;
         case 103:
            name = "Altitude above MSL";
            value1 = pds1112;
            units = "m";
            isNumeric = true;
            isSingleLayer = false;
            level =  pds1112 + " " + units;
            description = value1 + " m above mean sea level";
            break;
         case 104:
            name = "Layer between two altitudes above MSL";
            value1 = (pds11 * 100); // convert hm to m
            value2 = (pds12 * 100);
            units = "m";
            level =  value1 + "-" + value2 + " " + units;
            description = "Layer between " + pds11 + " and " +
                          pds12 + " m above mean sea level";
            break;
         case 105:
            name = "fixed height above ground";
            value1 = pds1112;
            units = "m";
            isNumeric = true;
            isSingleLayer = false;
            level = value1 + units;
            description = value1 + " m above ground";
            break;
         case 106:
            name = "layer between two height levels";
            value1 = (pds11 * 100); // convert hm to m
            value2 = (pds12 * 100);
            units = "m";
            isNumeric = true;
            level = value1 + "-" + value2 + " m AGL";
            description = "Layer between " + value1 + " and " +
                          value2 + " m above ground";
            break;
         case 107:
            name = "Sigma level";
            value1 = (pds1112/10000.0f);
            level = "sigma=" + value1;
            units = "sigma";
            isNumeric = true;
            isSingleLayer = false;
            isIncreasingUp = false;
            description = "sigma = " + value1;
            break;
         case 108:
            name = "Layer between two sigma layers";
            value1 = (pds11 / 100.0f);
            value2 = (pds12 / 100.0f);
            isNumeric = true;
            level = "sigma " + value1 + "-" + value2;
            description = "Layer between sigma levels " + value1 + " and " + value2;
            break;
         case 109:
            name = "hybrid level";
            value1 = pds1112;
            isNumeric = true;
            level = "hybrid level " + value1;
            description = "hybrid level " + value1;
            break;
         case 110:
            name = "Layer between two hybrid levels";
            value1 = pds11;
            value2 = pds12;
            isNumeric = true;
            level = "hybrid " + value1 + "-" + value2;
            description = "Layer between hybrid levels " + value1 + " and " + value2;
            break;
         case 111:
            name = "Depth below land surface";
            value1 = pds1112;
            units = "cm";
            isNumeric = true;
            level = value1 + " " + units;
            description = value1 + " " + units;
            break;
         case 112:
            name = "Layer between two levels below land surface";
            value1 = pds11;
            value2 = pds12;
            units = "cm";
            isNumeric = true;
            level = value1 + " - " + value2 + " " + units;
            description = "Layer between " + value1 + " and " + value2 +
                          " cm below land surface";
            break;
         case 113:
            name = "Isentropic (theta) level";
            value1 = pds1112;
            units = "K";
            isNumeric = true;
            isSingleLayer = false;
            level = value1 + " K";
            description = value1 + " K";
            break;
        case 114:
            name = "Layer between two isentropic layers";
            value1 = (pds11+475);
            value2 = (pds12+475);
            units = "K";
            isNumeric = true;
            description = "Layer between " + value1 + " and " + value2 + " K";
            break;
        case 116:
            name = "Layer between pressure differences from ground to levels";
            value1 = pds11;
            value2 = pds12;
            units = "hPa";
            isNumeric = true;
            level = value1 + units + " - " + value2 + units;
            description = "Layer between pressure differences from ground: " +
                           value1 + " and " + value2 + " K";
            break;
         case 125:
            name = "Height above ground (high precision)";
            value1 = pds1112;
            units = "cm";
            isNumeric = true;
            isSingleLayer = false;
            level = value1 + " " + units;
            description = value1 + " " + units + " above ground";
            break;
         case 160:
            name = "Depth below sea level";
            value1 = pds1112;
            units = "m";
            isNumeric = true;
            level = value1 + " m below sea level";
            description = pds1112 + " m below sea level";
            break;
         case 200:
            name = description = level = "entire atmosphere layer";
            break;
         case 201:
            name = description = level = "entire ocean layer";
            break;
         case 204:
            name = description = level = "Highest tropospheric freezing level";
            break;
         case 214:
            name = description = level = "Low Cloud Layer";
            break;
         case 224:
            name = description = level = "Middle Cloud Layer";
            break;
         case 234:
            name = description = level = "High Cloud Layer";
            break;
         default:
            name = description = "level " + index;
            System.out.println("GribPDSLevel: Table 3 level "+index+" is not known yet");
            break;
      }
   }

   public int getIndex(){
      return index;
   }

   public String getName(){
      return name;
   }

   public String getLevel(){
      return level;
   }

   public String getDesc(){
      return description;
   }

   public String getUnits(){
      return units;
   }

   public float getValue1(){
      return value1;
   }

   public float getValue2(){
      return value2;
   }

   public boolean getIsNumeric(){
      return isNumeric;
   }

   public boolean getIsIncreasingUp(){
      return isIncreasingUp;
   }

   public boolean getIsSingleLayer(){
      return isSingleLayer;
   }

   /**
    * Formats the class for output
    */
   public String toString(){
      return "  Parameter:" + '\n' +
             "        parameter id: " + this.index + "\n" +
             "        name: " + this.name + "\n" +
             "        description: " + this.description + "\n" +
             "        units: " + this.units + "\n" +
             "        short descr: " + this.level + "\n" +
             "        increasing up?: " + this.isIncreasingUp + "\n" +
             "        single layer?: " + this.isSingleLayer + "\n" +
             "        value1: " + this.value1 + "\n" +
             "        value2: " + this.value2 + "\n";
   }

   /**
    * rdg - added equals method
    * didn't check everything as most are set in the constructor
    */
   public boolean equals(Object obj){
      if (!(obj instanceof GribPDSLevel))
         return false;

      // quick check to see if same object
      if (this == obj) return true;

      GribPDSLevel lvl = (GribPDSLevel)obj;
      if (index != lvl.getIndex()) return false;
      if (value1 != lvl.getValue1()) return false;
      if (value2 != lvl.getValue2()) return false;

      return true;
   }

   /**
    * rdg - added this method to be used in a comparator for sorting while
    *       extracting records.
    *
    * @param obj - the GribRecordGDS to compare to
    * @returns - -1 if level is "less than" this, 0 if equal, 1 if level is "greater than" this.
    *
    */
   public int compare(GribPDSLevel level){
      if (this.equals(level))
         return 0;

      // check if level is less than this
      if (index > level.getIndex()) return -1;
      if (value1 > level.getValue1()) return -1;
      if (value2 > level.getValue2()) return -1;

      return 1;
   }
}

