/*
 * GribRecordBMS.java  1.0  01/01/2001
 *
 * (C) Benjamin Stark
 */

package net.sourceforge.jgrib;

import java.io.*;


/**
 * This class is an input stream wrapper that can read a specific number of
 * bytes and bits from an input stream.
 *
 * @author  Benjamin Stark
 * @version 1.0
 */

public class BitInputStream extends FilterInputStream
{


   /**
    * Buffer for one byte which will be processed bit by bit.
    */
   protected int bitBuf = 0;

   /**
    * Current bit position in <tt>bitBuf</tt>.
    */
   protected int bitPos = 0;


   /**
    * Constructs a bit input stream from an <tt>InputStream</tt> object.
    *
    * @param in input stream that will be wrapped
    */
   public BitInputStream(InputStream in)
   {

      super(in);
   }


   /**
    * Read an unsigned 8 bit value.
    *
    * @return unsigned 8 bit value as integer
    */
   public int readUI8() throws IOException
   {

      int ui8 = in.read();

      if (ui8 < 0)
         throw new IOException("End of input.");

      return ui8;
   }


   /**
    * Read specific number of unsigned bytes from the input stream.
    *
    * @param length number of bytes to read and return as integers
    *
    * @return unsigned bytes as integer values
    */
   public int[] readUI8(int length) throws IOException
   {

      int[] data = new int[length];
      int read = 0;

      for (int i = 0; i < length && read >= 0; i++)
         data[i] = read = this.read();

      if (read < 0)
         throw new IOException("End of input.");

      return data;
   }


   /**
    * Read specific number of bytes from the input stream.
    *
    * @param length number of bytes to read
    *
    * @return array of read bytes
    */
   public byte[] read(int length) throws IOException
   {

// OA this original jgrib code makes no sense
//       int numRead = this.read(data);
//
//       if (numRead < length) {
//
//           // retry reading
//           int numReadRetry = this.read(data, numRead, data.length - numRead);
//
//           if (numRead + numReadRetry < length)
//               throw new IOException("Unexpected end of input.");
//       }

       // rewritten by OA
      byte[] data = new byte[length];

       int n = 0;
       int pos = 0;
       while (n < length) {
           int count = read(data, pos + n, length - n);
           if (count < 0) throw new EOFException("Unexpected end of input.");
           n += count;
       }

      return data;
   }


   /**
    * Read an unsigned value from the given number of bits.
    *
    * @param numBits number of bits used for the unsigned value
    *
    * @return value read from <tt>numBits</tt> bits as long
    */
   public long readUBits(int numBits) throws IOException
   {

      if (numBits == 0) return 0;

      int bitsLeft = numBits;
      long result = 0;

      if (this.bitPos == 0)
      {

         this.bitBuf = in.read();
         this.bitPos = 8;
      }

      while (true)
      {

         int shift = bitsLeft - this.bitPos;
         if (shift > 0)
         {

            // Consume the entire buffer
            result |= this.bitBuf << shift;
            bitsLeft -= this.bitPos;

            // Get the next byte from the input stream
            this.bitBuf = in.read();
            this.bitPos = 8;
         }
         else
         {

            // Consume a portion of the buffer
            result |= this.bitBuf >> -shift;
            this.bitPos -= bitsLeft;
            this.bitBuf &= 0xff >> (8 - this.bitPos);   // mask off consumed bits

            return result;
         }
      }
   }


   /**
    * Read a signed value from the given number of bits
    *
    * @param numBits number of bits used for the signed value
    *
    * @return value read from <tt>numBits</tt> bits as integer
    */
   public int readSBits(int numBits) throws IOException
   {

      // Get the number as an unsigned value.
      long uBits = readUBits(numBits);

      // Is the number negative?
      if ((uBits & (1L << (numBits - 1))) != 0)
      {

         // Yes. Extend the sign.
         uBits |= -1L << numBits;
      }

      return (int) uBits;
   }

}

