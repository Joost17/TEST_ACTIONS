The mctools command-line executable is the entry point for both the mcrecoverytool and the dbinittool.

For latest help on the use of the tool use our wiki or run the mctools command-line executable.

linux:
     /opt/fews/bin/linux/mctools mcrecoverytool --help

windows:
     d:\fews\bin\windows\mctools.exe mcrecoverytool --help
